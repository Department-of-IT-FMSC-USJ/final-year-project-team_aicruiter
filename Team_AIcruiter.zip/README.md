---
title: AIcruiter1
emoji: 😎
colorFrom: blue
colorTo: green
sdk: docker
pinned: false
---