/**
 * AIcruiter — Frontend Application Logic
 * ==========================================
 * Handles:
 *  - Multi-screen navigation
 *  - File upload & setup form
 *  - Camera / microphone access
 *  - Interview flow (questions → TTS → user answers)
 *  - Web Speech API (speech recognition)
 *  - Periodic frame capture & facial analysis
 *  - Final report rendering
 */

"use strict";

const API = ""; // Same origin (Flask serves both)
const INTERVIEW_BOOTSTRAP_KEY = "candidateInterviewBootstrap";
const INTERVIEW_COMPLETE_NAME_KEY = "candidateInterviewCompleteName";

//  Emotion color map
const EMOTION_COLORS = {
  happy: "#10b981",
  neutral: "#94a3b8",
  sad: "#60a5fa",
  angry: "#ef4444",
  fear: "#a78bfa",
  disgust: "#f59e0b",
  surprise: "#f472b6",
};

//  State
const State = {
  sessionId: null,
  candidateId: null,
  candidate: {},
  questions: [],
  currentIndex: 0,
  qaHistory: [],
  cameraStream: null,
  cameraEnabled: false,
  micEnabled: false,
  transcript: "",
  recognition: null,
  timerInterval: null,
  elapsedSeconds: 0,
  faceInterval: null,
  currentAudio: null,
  emotionHistory: [],
  isSpeaking: false,
  questionAudio: null,
  speechVoice: null,
  preferredVoice: null,
  meetingId: null,
  introPhase: false,
  introTranscript: "",
};

//  Initialisation

window.addEventListener("DOMContentLoaded", async () => {
  // Check for meetingId in URL search params (direct link)
  const params = new URLSearchParams(window.location.search);
  let mid = params.get("meetingId");

  // Also check hash (SPA style)
  if (!mid && window.location.hash.includes("meetingId=")) {
    mid = window.location.hash.split("meetingId=")[1];
  }

  const pageMode = _getPageMode();
  const meetingContext = _parseMeetingContext(mid);

  if (pageMode === "candidate-interview") {
    window.speechSynthesis.getVoices(); // Pre-load voices
    await _bootInterviewConductPage(meetingContext);
    return;
  }

  if (meetingContext.meetingId) {
    joinMeeting(meetingContext.meetingId);
  }
});

function _getPageMode() {
  return document.body?.dataset?.page || "";
}

function _parseMeetingContext(rawMeetingId) {
  const raw = String(rawMeetingId || "")
    .trim()
    .replace(/\s+/g, "");
  const isInterviewRoute = /\/interview$/i.test(raw);
  const meetingId = raw.replace(/\/interview$/i, "").toUpperCase();
  return { raw, meetingId, isInterviewRoute };
}

function _saveInterviewBootstrap(data) {
  try {
    window.sessionStorage.setItem(
      INTERVIEW_BOOTSTRAP_KEY,
      JSON.stringify(data),
    );
    return true;
  } catch (err) {
    console.warn("Failed to save interview bootstrap state:", err);
    return false;
  }
}

function _loadInterviewBootstrap() {
  try {
    const raw = window.sessionStorage.getItem(INTERVIEW_BOOTSTRAP_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (err) {
    console.warn("Failed to load interview bootstrap state:", err);
    return null;
  }
}

async function _ensureInterviewCameraStream() {
  if (State.cameraStream) return true;

  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: true,
      audio: true,
    });
    State.cameraStream = stream;
    State.cameraEnabled = true;
    State.micEnabled = true;

    const userVid = document.getElementById("user-video");
    if (userVid) userVid.srcObject = stream;
    return true;
  } catch (err) {
    console.error("Camera/microphone access failed on interview page:", err);
    return false;
  }
}

async function _bootInterviewConductPage(meetingContext) {
  if (!meetingContext.meetingId) {
    _showLandingError(
      "Interview link is invalid. Please use your meeting link again.",
    );
    return;
  }

  State.meetingId = meetingContext.meetingId;

  const bootstrap = _loadInterviewBootstrap();
  if (!bootstrap || !bootstrap.sessionId) {
    _showLandingError(
      "Interview session not found. Please complete registration again.",
    );
    window.setTimeout(() => {
      window.location.href = `/?meetingId=${encodeURIComponent(State.meetingId)}`;
    }, 1200);
    return;
  }

  const bootstrapMeetingId = String(bootstrap.meetingId || "")
    .trim()
    .toUpperCase();
  if (bootstrapMeetingId && bootstrapMeetingId !== State.meetingId) {
    _showLandingError(
      "Meeting mismatch detected. Please start again from your registration page.",
    );
    window.setTimeout(() => {
      window.location.href = `/?meetingId=${encodeURIComponent(State.meetingId)}`;
    }, 1200);
    return;
  }

  State.sessionId = bootstrap.sessionId;
  State.candidateId = bootstrap.candidateId || null;
  State.candidate = bootstrap.candidate || {};
  State.questions = Array.isArray(bootstrap.questions)
    ? bootstrap.questions
    : [];
  State.currentIndex = 0;
  State.qaHistory = [];

  // Show loading screen and ensure inner overlay content is visible
  showScreen("screen-loading");

  const mediaReady = await _ensureInterviewCameraStream();
  if (!mediaReady) {
    _showLandingError(
      "Camera and microphone permissions are required to continue the interview.",
    );
    return;
  }

  // Replace auto-launch with a 'Ready' button to ensure user gesture for STT/Audio
  const msg = document.getElementById("loading-message");
  if (msg) {
    msg.innerHTML = `
            <div style="display:flex; flex-direction:column; align-items:center; gap:20px;">
                <span style="font-size:1.4rem; font-weight:700;">AI Interviewer is Ready</span>
                <p style="font-size:0.9rem; color:var(--text-muted); margin-bottom:10px;">Click the button below to join the live session and begin your interview.</p>
                <button class="btn-xl" style="width:220px;" onclick="window.launchInterview()">Start Session</button>
            </div>
        `;
    // Hide the subtitle text below (if it exists)
    const sub = msg.nextElementSibling;
    if (sub) sub.style.display = "none";
  }

  // Expose needed functions to global scope
  window.launchInterview = launchInterview;
  window.toggleCamera = toggleCamera;
  window.toggleMic = toggleMic;
}

function syncMeetingIdInUrl(mid) {
  if (
    !mid ||
    !window.history ||
    typeof window.history.replaceState !== "function"
  )
    return;
  const params = new URLSearchParams(window.location.search);
  params.set("meetingId", mid);
  const nextUrl = `${window.location.pathname}?${params.toString()}`;
  window.history.replaceState({}, "", nextUrl);
}

async function joinMeeting(mid) {
  const normalizedMid = String(mid || "")
    .trim()
    .replace(/\s+/g, "")
    .toUpperCase();
  if (!normalizedMid) {
    _showLandingError("Meeting link invalid or expired.");
    return;
  }
  State.meetingId = normalizedMid;
  try {
    const res = await fetch(
      `${API}/api/meeting/${encodeURIComponent(normalizedMid)}`,
    );
    const data = await res.json();

    if (res.ok) {
      syncMeetingIdInUrl(normalizedMid);
      const mtgTitle = document.getElementById("mtg-title");
      if (mtgTitle)
        mtgTitle.textContent =
          "Interview for: " + (data.job_title || "Position");
      showScreen("screen-setup"); // AUTO-NAVIGATE
    } else {
      _showLandingError(data.error || "Meeting link invalid or expired.");
    }
  } catch (e) {
    console.error("Failed to fetch meeting details", e);
    _showLandingError("Connection error. Please try again.");
  }
}

async function startMeetingSetup() {
  const midInput = document.getElementById("inp-meeting-id");
  const mid = (midInput?.value || "").trim().replace(/\s+/g, "").toUpperCase();
  if (!mid) return alert("Please enter a valid Meeting ID");

  if (midInput) {
    midInput.value = mid;
  }

  const btn = document.getElementById("btn-join-meeting");
  const text = document.getElementById("btn-join-text");
  const spin = document.getElementById("join-spinner");
  const err = document.getElementById("landing-error");

  if (err) err.classList.add("hidden");
  btn.disabled = true;
  text.textContent = "Verifying...";
  spin.classList.remove("hidden");

  try {
    const res = await fetch(`${API}/api/meeting/${encodeURIComponent(mid)}`);
    const data = await res.json();

    if (!res.ok)
      throw new Error(data.error || "Meeting link invalid or expired.");

    State.meetingId = mid;
    syncMeetingIdInUrl(mid);

    const mtgTitle = document.getElementById("mtg-title");
    if (mtgTitle)
      mtgTitle.textContent = "Interview for: " + (data.job_title || "Position");

    showScreen("screen-setup");
  } catch (e) {
    _showLandingError(e.message);
  } finally {
    btn.disabled = false;
    text.textContent = "Join Secure Session";
    spin.classList.add("hidden");
  }
}

function _showLandingError(msg) {
  const landingError = document.getElementById("landing-error");
  if (landingError) {
    landingError.textContent = msg;
    landingError.classList.remove("hidden");
    return;
  }

  const setupError = document.getElementById("setup-error");
  if (setupError) {
    setupError.textContent = msg;
    setupError.classList.remove("hidden");
    showScreen("screen-setup");
    return;
  }

  alert(msg);
}

function showToast(text) {
  let container = document.getElementById("toast-container");
  if (!container) {
    container = document.createElement("div");
    container.id = "toast-container";
    document.body.appendChild(container);
  }
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = text;
  container.appendChild(toast);
  setTimeout(() => {
    toast.classList.add("hide");
    setTimeout(() => toast.remove(), 500);
  }, 4000);
}

//  Screen management

function showScreen(id) {
  // Only hide top-level screens (elements with an ID that starts with 'screen-' or 'report-overlay')
  // Do NOT hide nested .overlay-screen children inside screens
  document.querySelectorAll(".screen").forEach((s) => {
    s.classList.remove("active");
    s.classList.add("hidden");
  });
  // Also hide standalone overlay screens (like report-overlay, end-modal) but NOT nested ones
  document
    .querySelectorAll("body > .overlay-screen, body > .modal-backdrop")
    .forEach((s) => {
      s.classList.remove("active");
      s.classList.add("hidden");
    });
  const target = document.getElementById(id);
  if (target) {
    target.classList.remove("hidden");
    target.classList.add("active");
    // Ensure any overlay-screen children inside this target are also visible
    target.querySelectorAll(".overlay-screen").forEach((child) => {
      child.classList.remove("hidden");
    });
  }
}

//  Camera

async function toggleCamera() {
  if (State.cameraEnabled) {
    stopCamera();
    return;
  }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: true,
      audio: true,
    });
    State.cameraStream = stream;
    State.cameraEnabled = true;
    State.micEnabled = true;

    const preview = document.getElementById("cam-preview");
    if (preview) {
      preview.srcObject = stream;
      document.getElementById("cam-overlay")?.classList.add("hidden");
    }

    const userVid = document.getElementById("user-video");
    if (userVid) userVid.srcObject = stream;

    const btn = document.getElementById("cam-btn-text");
    if (btn) btn.textContent = "📷 Disable Camera";
  } catch (err) {
    console.error("Camera error:", err);
    showToast("Could not access camera/microphone. Please allow permissions.");
  }
}

function stopCamera() {
  if (State.cameraStream) {
    State.cameraStream.getTracks().forEach((t) => t.stop());
    State.cameraStream = null;
  }
  State.cameraEnabled = false;
  State.micEnabled = false;
  const preview = document.getElementById("cam-preview");
  if (preview) preview.srcObject = null;
  const btnText = document.getElementById("cam-btn-text");
  if (btnText) btnText.textContent = "📷 Enable Camera";
  _setDot("cam-status", "");
  _setDot("mic-status", "");
}

function _setDot(statusId, cls) {
  const el = document.getElementById(statusId);
  if (!el) return;
  const dot = el.querySelector(".dot");
  if (dot) {
    dot.className = "dot";
    if (cls) dot.classList.add(cls);
  }
}

//  File upload helpers

function handleFileSelect(input, zoneId, nameId) {
  const file = input.files[0];
  if (!file) return;
  const zone = document.getElementById(zoneId);
  const name = document.getElementById(nameId);
  if (zone) zone.classList.add("has-file");
  if (name) {
    name.textContent = `✓ ${file.name}`;
    name.style.color = "#10b981";
  }
}

//  Drag-and-drop

["cv-zone", "jd-zone"].forEach((zoneId) => {
  const zone = document.getElementById(zoneId);
  if (!zone) return;
  zone.addEventListener("dragover", (e) => {
    e.preventDefault();
    zone.style.borderColor = "#7c3aed";
  });
  zone.addEventListener("dragleave", () => {
    zone.style.borderColor = "";
  });
  zone.addEventListener("drop", (e) => {
    e.preventDefault();
    zone.style.borderColor = "";
    const file = e.dataTransfer.files[0];
    if (!file) return;
    const inputId = zoneId === "cv-zone" ? "inp-cv" : "inp-jd";
    const nameId = zoneId === "cv-zone" ? "cv-name" : "jd-name";
    const input = document.getElementById(inputId);
    if (input) {
      // Assign via DataTransfer
      const dt = new DataTransfer();
      dt.items.add(file);
      input.files = dt.files;
      handleFileSelect(input, zoneId, nameId);
    }
  });
});

//  Setup form submission

async function handleSetupSubmit(e) {
  if (e) e.preventDefault();

  const btn = document.getElementById("btn-submit-setup");
  const text = document.getElementById("btn-submit-text");
  const spin = document.getElementById("setup-spinner");
  const err = document.getElementById("setup-error");

  // Reset UI
  if (err) {
    err.classList.add("hidden");
    err.textContent = "";
  }

  // Validate camera
  if (!State.cameraEnabled) {
    _showSetupError("Please enable your camera before starting.");
    return;
  }

  const name = document.getElementById("inp-name").value.trim();
  const email = document.getElementById("inp-email").value.trim();

  if (!name || !email) {
    _showSetupError("Please enter your full name and email address.");
    return;
  }

  if (!State.meetingId) {
    _showSetupError(
      "Invalid session. Please return home and enter a Meeting ID.",
    );
    return;
  }

  // Prepare data
  const formData = new FormData();
  formData.append("name", name);
  formData.append("email", email);
  formData.append("meeting_id", State.meetingId);

  // Visual feedback
  btn.disabled = true;
  text.textContent = "Initiating Session…";
  spin.classList.remove("hidden");

  if (document.getElementById("screen-loading")) {
    showScreen("screen-loading");
  }

  try {
    const res = await fetch(`${API}/api/upload`, {
      method: "POST",
      body: formData,
    });
    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.error || "Server error occured.");
    }

    State.sessionId = data.session_id;
    State.candidateId = data.candidate_id;
    State.candidate = data.candidate;
    State.questions = data.questions || [];

    if (State.questions.length === 0) {
      throw new Error("No questions were generated for this role.");
    }

    const pageMode = _getPageMode();
    if (pageMode === "candidate-registration") {
      const saved = _saveInterviewBootstrap({
        sessionId: State.sessionId,
        candidateId: State.candidateId,
        candidate: State.candidate,
        questions: State.questions,
        meetingId: State.meetingId,
      });

      if (!saved) {
        throw new Error("Unable to start interview session. Please try again.");
      }

      await _delay(250);
      window.location.href = `/?meetingId=${encodeURIComponent(State.meetingId)}/interview`;
      return;
    }

    await _delay(1500);
    launchInterview();
  } catch (ex) {
    console.error("Submission failed:", ex);
    showScreen("screen-setup");
    _showSetupError(ex.message || "An unexpected error occurred.");
    btn.disabled = false;
    text.textContent = "Initiate Interview";
    spin.classList.add("hidden");
  }
}

function _showSetupError(msg) {
  const el = document.getElementById("setup-error");
  if (el) {
    el.textContent = msg;
    el.classList.remove("hidden");
  }
}

//  Loading animation

function startLoadingAnimation() {
  const steps = ["step-parse", "step-analyze", "step-generate", "step-ready"];
  const messages = [
    "Parsing your CV and job description…",
    "Analysing your skills and requirements…",
    "Generating personalised questions with Gemini…",
    "Preparing your AI interviewer…",
  ];
  let i = 0;
  const advance = () => {
    if (i > 0) {
      const prev = document.getElementById(steps[i - 1]);
      if (prev) {
        prev.classList.remove("active");
        prev.classList.add("done");
      }
    }
    if (i < steps.length) {
      const cur = document.getElementById(steps[i]);
      if (cur) cur.classList.add("active");
      const msg = document.getElementById("loading-message");
      if (msg) msg.textContent = messages[i];
      i++;
      setTimeout(advance, 1200);
    }
  };
  advance();
}

//  Launch interview

async function launchInterview() {
  console.log(
    "[AIcruiter] launchInterview() called. sessionId:",
    State.sessionId,
    "questions:",
    State.questions?.length,
  );

  showScreen("screen-interview");

  // Ensure camera stream is available (re-request if lost during page transition)
  if (!State.cameraStream) {
    console.log("[AIcruiter] Camera stream missing, re-acquiring...");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: true,
        audio: true,
      });
      State.cameraStream = stream;
      State.cameraEnabled = true;
      State.micEnabled = true;
    } catch (err) {
      console.error("[AIcruiter] Failed to re-acquire camera:", err);
    }
  }

  // Pipe camera to interview video
  const vid = document.getElementById("user-video");
  if (vid && State.cameraStream) {
    vid.srcObject = State.cameraStream;
    console.log("[AIcruiter] Camera stream attached to user-video");
  } else {
    console.warn(
      "[AIcruiter] Could not attach camera. vid:",
      !!vid,
      "stream:",
      !!State.cameraStream,
    );
  }

  const nameTag = document.getElementById("user-name-tag");
  if (nameTag) nameTag.textContent = State.candidate.name || "Candidate";

  // Start timer
  startTimer();
  console.log("[AIcruiter] Timer started");

  // Start face analysis loop (every 5 seconds)
  startFaceAnalysis();

  // Start speech recognition
  startSpeechRecognition();

  //  Play AI Introduction + ask 'tell me about yourself'
  setAIStatus("Welcoming candidate...");
  try {
    const res = await fetch(`${API}/api/interview/intro/${State.sessionId}`);
    const data = await res.json();
    if (data.audio || data.text) {
      // Play welcome + "tell me about yourself" combined
      const qText = document.getElementById("q-text");
      const qCat = document.getElementById("q-category");
      const counter = document.getElementById("q-counter");
      if (qText)
        qText.textContent =
          data.text || "Welcome! Could you tell me about yourself?";
      if (qCat) qCat.textContent = "✦ Introduction";
      if (counter) counter.textContent = "Introduction";
      await playTTSAudio(
        data.audio,
        data.text || "Welcome! Could you tell me about yourself?",
      );
    }
  } catch (e) {
    console.warn("[AIcruiter] Intro failed, continuing to questions:", e);
  }

  // Set intro phase — next answer submitted will be the 'about yourself' answer
  State.introPhase = true;
  State.introTranscript = "";
  State.transcript = "";
  _updateTranscript("");
  const ta = document.getElementById("text-answer");
  if (ta) ta.value = "";
  setAIStatus("Please tell us about yourself…");

  // Do NOT call askNextQuestion() yet — wait for intro answer submission
}

//  Timer

function startTimer() {
  State.elapsedSeconds = 0;
  State.timerInterval = setInterval(() => {
    State.elapsedSeconds++;
    const m = String(Math.floor(State.elapsedSeconds / 60)).padStart(2, "0");
    const s = String(State.elapsedSeconds % 60).padStart(2, "0");
    const el = document.getElementById("interview-timer");
    if (el) el.textContent = `${m}:${s}`;
  }, 1000);
}

//  Face analysis

function startFaceAnalysis() {
  State.faceInterval = setInterval(captureAndAnalyseFace, 5000);
}

async function captureAndAnalyseFace() {
  if (!State.sessionId || !State.cameraStream) return;
  const vid = document.getElementById("user-video");
  if (!vid || vid.readyState < 2) return;

  try {
    const canvas = document.createElement("canvas");
    canvas.width = 320;
    canvas.height = 240;
    const ctx = canvas.getContext("2d");
    ctx.drawImage(vid, 0, 0, canvas.width, canvas.height);
    const b64 = canvas.toDataURL("image/jpeg", 0.7);

    const res = await fetch(`${API}/api/analyse-frame`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ session_id: State.sessionId, frame: b64 }),
    });
    const data = await res.json();
    if (data.emotions) {
      updateEmotionHUD(data);
      State.emotionHistory.push({
        emotion: data.dominant_emotion,
        ts: State.elapsedSeconds,
      });
      updateEmotionTimeline();
    }
  } catch (err) {
    // Silently ignore face analysis errors during interview
  }
}

function updateEmotionHUD(data) {
  const valEl = document.getElementById("emotion-value");
  const barsEl = document.getElementById("emotion-bars");
  if (!valEl || !barsEl) return;

  valEl.textContent = data.dominant_emotion || "—";
  valEl.style.color = EMOTION_COLORS[data.dominant_emotion] || "#fff";

  const emotions = data.emotions || {};
  const max = Math.max(...Object.values(emotions), 1);
  barsEl.innerHTML = "";

  Object.entries(emotions).forEach(([name, score]) => {
    const pct = Math.round((score / max) * 100);
    const color = EMOTION_COLORS[name] || "#7c3aed";
    barsEl.innerHTML += `
      <div class="e-bar-wrap" title="${name}: ${score.toFixed(1)}%">
        <div class="e-bar" style="height:${pct}%;background:${color}"></div>
        <span class="e-bar-label">${name.slice(0, 3)}</span>
      </div>`;
  });
}

function updateEmotionTimeline() {
  const container = document.getElementById("eh-bars");
  if (!container) return;
  // Keep only last 30 entries
  const recent = State.emotionHistory.slice(-30);
  container.innerHTML = recent
    .map((e) => {
      const color = EMOTION_COLORS[e.emotion] || "#7c3aed";
      return `<div class="eh-segment" style="background:${color};height:${Math.random() * 60 + 20}%"
              data-tooltip="${e.emotion} @ ${e.ts}s"></div>`;
    })
    .join("");
}

//  Ask next question

async function askNextQuestion() {
  if (!State.sessionId) return;

  setAIStatus("Thinking…");
  setAISpeaking(false);

  try {
    const res = await fetch(`${API}/api/next-question/${State.sessionId}`);
    const data = await res.json();

    if (data.done) {
      // All questions answered -> Wrap up phase
      setAIStatus("Wrapping up...");
      try {
        const wrapRes = await fetch(
          `${API}/api/interview/wrapup/${State.sessionId}`,
        );
        const wrapData = await wrapRes.json();
        if (wrapData.audio) {
          // Show wrap-up text in the question card
          const qText = document.getElementById("q-text");
          if (qText) qText.textContent = wrapData.text;
          await playTTSAudio(wrapData.audio, wrapData.text);
        }
      } catch (e) {
        console.warn("Wrapup failed", e);
      }

      await _delay(500);
      endInterview();
      return;
    }

    State.currentIndex = data.index;
    State.questionAudio = data.audio;

    // Update UI
    const counter = document.getElementById("q-counter");
    if (counter)
      counter.textContent = `Question ${data.index + 1} / ${State.questions.length || data.total}`;

    const qText = document.getElementById("q-text");
    if (qText) qText.textContent = data.question.question;

    const qCat = document.getElementById("q-category");
    if (qCat) qCat.textContent = data.question.category || "";

    const tArea = document.getElementById("text-answer");
    if (tArea) tArea.value = "";
    State.transcript = "";
    _updateTranscript("");

    // Play AI voice (always call, will use browser fallback if data.audio is missing)
    await playTTSAudio(data.audio, data.question.question);
  } catch (err) {
    console.error("Next Q error:", err);
    setAIStatus("Ready");
  }
}

async function replayQuestion() {
  const text = document.getElementById("q-text").textContent;
  await playTTSAudio(State.questionAudio, text);
}

//  TTS playback

async function playTTSAudio(b64mp3, questionText) {
  return new Promise((resolve) => {
    // Stop any previous audio or speech synthesis
    if (State.currentAudio) {
      State.currentAudio.pause();
      State.currentAudio = null;
    }
    window.speechSynthesis.cancel();

    if (!b64mp3) {
      console.warn(
        "TTS audio missing, falling back to browser speech synthesis.",
      );
      const msg = new SpeechSynthesisUtterance(questionText);

      // Re-use cached voice or find a new one once
      if (!State.preferredVoice) {
        const voices = window.speechSynthesis.getVoices();
        State.preferredVoice = voices.find(
          (v) =>
            (v.name.includes("Google US English") ||
              v.name.includes("Female") ||
              v.name.includes("Zira") ||
              v.name.includes("Samantha") ||
              v.name.includes("Ava")) &&
            v.lang.startsWith("en"),
        );
      }

      if (State.preferredVoice) msg.voice = State.preferredVoice;

      State.speechVoice = msg; // Hold reference to prevent GC on some browsers

      msg.onend = () => {
        setAISpeaking(false);
        setAIStatus("Listening to your answer…");
        State.speechVoice = null;
        resolve();
      };
      msg.onerror = (e) => {
        console.error("Speech synthesis error:", e);
        State.speechVoice = null;
        resolve();
      };

      setAIStatus("Speaking…");
      setAISpeaking(true);
      window.speechSynthesis.speak(msg);

      // Safety timeout: resolve if onend never fires (e.g. browser blocks it)
      setTimeout(() => {
        if (State.speechVoice === msg) {
          State.speechVoice = null;
          setAISpeaking(false);
          setAIStatus("Listening to your answer…");
          resolve();
        }
      }, 10000);
      return;
    }

    const audio = new Audio(`data:audio/mp3;base64,${b64mp3}`);
    State.currentAudio = audio;

    setAIStatus("Speaking…");
    setAISpeaking(true);

    audio.onended = () => {
      setAISpeaking(false);
      setAIStatus("Listening to your answer…");
      State.currentAudio = null;
      resolve();
    };
    audio.onerror = (e) => {
      console.error("Audio playback error:", e);
      setAISpeaking(false);
      setAIStatus("Listening to your answer…");
      resolve();
    };

    audio.play().catch((e) => {
      console.warn("Browser blocked autoplay:", e);
      setAISpeaking(false);
      setAIStatus("Listening to your answer…");
      resolve();
    });
  });
}

function setAISpeaking(on) {
  State.isSpeaking = on;
  const indicator = document.getElementById("ai-speaking");
  const mouth = document.getElementById("avatar-mouth");
  if (indicator) indicator.classList.toggle("active", on);
  if (mouth) mouth.classList.toggle("speaking", on);

  // Stop recognition while AI is speaking to avoid feedback loop
  if (on && State.recognition) {
    try {
      State.recognition.stop();
    } catch (e) {}
  } else if (!on && State.micEnabled && State.recognition) {
    // Resume listening after AI finishes
    setTimeout(() => {
      if (State.micEnabled && !State.isSpeaking) {
        try {
          State.recognition.start();
        } catch (e) {}
      }
    }, 500);
  }
}

function setAIStatus(text) {
  const el = document.getElementById("ai-status-text");
  if (el) el.textContent = text;
}

//  Microphone toggle

function toggleMic() {
  if (!State.recognition) {
    showToast(
      "Speech recognition not available in this browser. Type your answer instead.",
    );
    return;
  }
  if (State.micEnabled) {
    State.micEnabled = false;
    try {
      State.recognition.stop();
    } catch (e) {}
    _updateMicUI(false);
  } else {
    State.micEnabled = true;
    try {
      State.recognition.start();
    } catch (e) {}
    _updateMicUI(true);
  }
}

//  Speech recognition

function startSpeechRecognition() {
  const SpeechRecognition =
    window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    console.warn("SpeechRecognition API not supported in this browser.");
    showToast(
      "Speech Recognition is not supported on this browser or environment. Please use Google Chrome or Edge on localhost/HTTPS.",
      8000,
    );
    return;
  }

  if (State.recognition) {
    try {
      State.recognition.stop();
    } catch (e) {}
  }

  const rec = new SpeechRecognition();
  rec.continuous = true;
  rec.interimResults = true;
  rec.lang = "en-US";

  rec.onstart = () => {
    console.log("Speech recognition started");
    State.micEnabled = true;
    _updateMicUI(true);
  };

  rec.onresult = (event) => {
    let interim = "";
    let final = "";
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const t = event.results[i][0].transcript;
      if (event.results[i].isFinal) final += t + " ";
      else interim += t;
    }
    if (final) State.transcript += final;

    const fullTranscript = State.transcript + interim;
    _updateTranscript(fullTranscript);

    // Mirror to textarea
    const area = document.getElementById("text-answer");
    if (area) {
      area.value = fullTranscript;
      // Scroll to bottom
      area.scrollTop = area.scrollHeight;
    }

    // Auto-submit on silence detection
    if (State.silenceTimer) clearTimeout(State.silenceTimer);

    if (fullTranscript.trim().length > 0) {
      State.silenceTimer = setTimeout(() => {
        if (State.micEnabled && !State.isSpeaking) {
          console.log("Silence detected -> Auto submitting answer.");
          submitCurrentAnswer();
        }
      }, 3000); // 3 seconds of silence triggers submission
    }
  };

  rec.onerror = (err) => {
    console.warn("Speech Recognition error:", err.error);
    if (err.error === "not-allowed") {
      showToast(
        "Microphone access denied. Please enable it in browser settings.",
      );
      State.micEnabled = false;
      _updateMicUI(false);
    }
  };

  rec.onend = () => {
    console.log("Speech recognition ended");
    // Auto-restart if still "listening" and not speaking
    if (State.micEnabled && !State.isSpeaking) {
      setTimeout(() => {
        try {
          rec.start();
        } catch (e) {}
      }, 300);
    } else {
      _updateMicUI(false);
    }
  };

  State.recognition = rec;

  // Start listening
  try {
    rec.start();
  } catch (e) {
    console.error("Failed to start recognition:", e);
  }
}

function _updateMicUI(active) {
  const btn = document.getElementById("btn-mic");
  const icon = document.getElementById("mic-icon");
  if (btn) btn.classList.toggle("active", active);
  if (icon)
    icon.className = active
      ? "fa-solid fa-microphone-lines"
      : "fa-solid fa-microphone";
}

function _updateTranscript(text) {
  const el = document.getElementById("transcript-content");
  if (!el) return;
  if (!text.trim()) {
    el.innerHTML =
      '<span class="transcript-placeholder">Start speaking — your words appear here…</span>';
  } else {
    el.textContent = text;
    el.scrollTop = el.scrollHeight;
  }
}

function clearTranscript() {
  State.transcript = "";
  _updateTranscript("");
  const ta = document.getElementById("text-answer");
  if (ta) ta.value = "";
}

//  Submit answer

async function submitCurrentAnswer() {
  if (State.silenceTimer) clearTimeout(State.silenceTimer);

  //  INTRO PHASE: capture 'tell me about yourself' without scoring
  if (State.introPhase) {
    State.introPhase = false;
    const introAnswer =
      (document.getElementById("text-answer")?.value || "").trim() ||
      State.transcript.trim() ||
      "(No introduction provided)";
    State.introTranscript = introAnswer;

    // Stop mic briefly
    if (State.recognition) {
      try {
        State.recognition.stop();
      } catch (e) {}
    }
    State.micEnabled = false;

    // Save intro to server (no scoring)
    try {
      await fetch(`${API}/api/interview/save-intro/${State.sessionId}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ intro_answer: introAnswer }),
      });
    } catch (e) {
      console.warn("[AIcruiter] Failed to save intro answer:", e);
    }

    // Clear transcript and proceed to real questions
    State.transcript = "";
    _updateTranscript("");
    const ta = document.getElementById("text-answer");
    if (ta) ta.value = "";

    setAIStatus("Great! Now let's begin the interview...");

    // Brief ack then first real question
    const ackText =
      "Thank you for sharing! Now let's get started with your interview questions.";
    try {
      const ttsRes = await fetch(`${API}/api/tts`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: ackText }),
      });
      const ttsData = await ttsRes.json();
      await playTTSAudio(ttsData.audio, ackText);
    } catch (e) {
      await playTTSAudio(null, ackText);
    }

    // Restart mic then ask Q1
    if (State.recognition) {
      try {
        State.recognition.start();
        State.micEnabled = true;
      } catch (e) {}
    }
    await askNextQuestion();
    return;
  }

  const btn = document.getElementById("btn-answer");
  setAIStatus("Submitting your answer…");

  // Get answer from textarea (either typed or speech-to-text)
  const answer =
    document.getElementById("text-answer").value.trim() ||
    State.transcript.trim() ||
    "(No answer provided)";

  // Stop mic temporarily
  if (State.recognition) {
    try {
      State.recognition.stop();
    } catch (e) {}
  }
  State.micEnabled = false;

  try {
    const res = await fetch(`${API}/api/submit-answer`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        session_id: State.sessionId,
        question_index: State.currentIndex,
        answer,
      }),
    });
    const data = await res.json();

    // Record locally
    State.qaHistory.push({
      question: State.questions[State.currentIndex]?.question || "",
      answer,
      score: data.score || {},
    });

    //  Handle Dynamic Follow-up
    if (data.follow_up) {
      // Display follow-up in the UI as the current question
      document.getElementById("q-text").textContent = data.follow_up;
      document.getElementById("q-category").textContent = "clarification";
      document.getElementById("text-answer").value = "";
      State.transcript = "";
      _updateTranscript("");

      // Play follow-up audio
      await playTTSAudio(data.follow_up_audio, data.follow_up);

      // Re-enable button but DO NOT call askNextQuestion yet
      btn.disabled = false;
      btn.textContent = "✓ Submit Answer";
      if (State.recognition) {
        try {
          State.recognition.start();
          State.micEnabled = true;
        } catch (e) {}
      }
      return;
    }

    //  Normal progress: Play acknowledgement audio
    if (data.ack_audio) {
      await playTTSAudio(data.ack_audio, data.ack_text || "Thank you…");
    }

    // Ask next question
    btn.disabled = false;
    btn.textContent = "✓ Submit Answer";
    State.transcript = "";
    _updateTranscript("");

    // Restart mic
    if (State.recognition) {
      try {
        State.recognition.start();
        State.micEnabled = true;
      } catch (e) {}
    }

    await askNextQuestion();
  } catch (err) {
    console.error("Submit error:", err);
    showToast("Error submitting answer. Check your connection.");
    btn.disabled = false;
    btn.textContent = "✓ Submit Answer";
  }
}

async function skipQuestion() {
  const btn = document.getElementById("btn-answer");
  if (btn) btn.textContent = "⏳ Skipping…";

  // Stop mic temporarily
  if (State.recognition) {
    try {
      State.recognition.stop();
    } catch (e) {}
  }
  State.micEnabled = false;

  try {
    // We can just call askNextQuestion as the backend handles the index
    // Or we might need a specific skip endpoint if the backend tracks attempts
    await askNextQuestion();
    showToast("Question skipped");
  } catch (err) {
    console.error("Skip error:", err);
  } finally {
    if (btn) btn.textContent = "✓ Submit Answer";
    if (State.recognition) {
      try {
        State.recognition.start();
        State.micEnabled = true;
      } catch (e) {}
    }
  }
}

//  End interview

function confirmEndInterview() {
  document.getElementById("end-modal").classList.remove("hidden");
}

function closeModal() {
  document.getElementById("end-modal").classList.add("hidden");
}

async function endInterview() {
  closeModal();
  // Stop everything immediately
  clearInterval(State.timerInterval);
  clearInterval(State.faceInterval);
  if (State.recognition) {
    try {
      State.recognition.stop();
    } catch (e) {}
  }
  if (State.currentAudio) {
    try {
      State.currentAudio.pause();
    } catch (e) {}
  }

  // Notify server asynchronously (fire-and-forget)
  try {
    fetch(`${API}/api/end-interview`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ session_id: State.sessionId }),
    }).catch((e) => console.warn("end-interview notify failed:", e));
  } catch (e) {
    console.warn("end-interview exception:", e);
  }

  // Persist candidate name for final page
  const candidateName = State.candidate?.name || "Candidate";
  try {
    window.sessionStorage.setItem(INTERVIEW_COMPLETE_NAME_KEY, candidateName);
  } catch (e) {}

  // Redirect to interview complete page (keeps UX immediate)
  if (State.meetingId) {
    window.location.href = `/?meetingId=${encodeURIComponent(State.meetingId)}/interview_complete`;
    return;
  }

  // Fallback: show a simple complete screen
  renderReport({ candidate: State.candidate });
  showScreen("screen-report");
}

function animateReportProgress() {
  let progress = 0;
  const messages = [
    "Analysing your answers…",
    "Processing facial expression data…",
    "Consulting Gemini AI…",
    "Generating comprehensive report…",
    "Finalising decision…",
  ];
  let msgIdx = 0;
  const fill = document.getElementById("report-progress");
  const msg = document.getElementById("report-gen-msg");
  const iv = setInterval(() => {
    progress = Math.min(progress + Math.random() * 12, 95);
    if (fill) fill.style.width = progress + "%";
    if (Math.random() > 0.7 && msgIdx < messages.length - 1) {
      msgIdx++;
      if (msg) msg.textContent = messages[msgIdx];
    }
    if (progress >= 95) clearInterval(iv);
  }, 400);
}

//  Render report

function renderReport(report) {
  if (!report) return;
  const container = document.getElementById("report-container");
  if (!container) return;

  const candidate = report.candidate || State.candidate;

  container.innerHTML = `
        <div style="text-align: center; margin-top: 50px;">
            <div style="font-size: 5rem; color: var(--success); margin-bottom: 30px;">
                <i class="fa-solid fa-circle-check"></i>
            </div>
            <h1 style="font-size: 3rem; margin-bottom: 20px; font-family: 'Outfit';">Interview Complete</h1>
            <p style="color: var(--text-muted); font-size: 1.25rem; max-width: 600px; margin: 0 auto; line-height: 1.6;">
                Thank you for your time, <strong>${candidate.name || "Candidate"}</strong>! <br>
                Your interview session has been successfully recorded and submitted. 
                Our recruitment team will review your application and contact you soon regarding the next steps.
            </p>
            
            <div style="margin-top: 60px;">
                <button class="btn-xl" style="max-width: 300px;" onclick="location.reload()">Return to Portal</button>
            </div>
        </div>
    `;
}

//  Reset

function resetState() {
  Object.assign(State, {
    sessionId: null,
    candidateId: null,
    candidate: {},
    questions: [],
    currentIndex: 0,
    qaHistory: [],
    cameraStream: null,
    cameraEnabled: false,
    micEnabled: false,
    transcript: "",
    recognition: null,
    timerInterval: null,
    elapsedSeconds: 0,
    faceInterval: null,
    currentAudio: null,
    emotionHistory: [],
    isSpeaking: false,
    questionAudio: null,
  });
}

//  Toast

function showToast(msg, duration = 4000) {
  const t = document.createElement("div");
  t.textContent = msg;
  Object.assign(t.style, {
    position: "fixed",
    bottom: "24px",
    left: "50%",
    transform: "translateX(-50%)",
    background: "#1e1b4b",
    border: "1px solid rgba(124,58,237,0.4)",
    color: "#e2e8f0",
    padding: "12px 24px",
    borderRadius: "12px",
    fontSize: "0.9rem",
    zIndex: "9999",
    boxShadow: "0 8px 32px rgba(0,0,0,0.5)",
    animation: "fadeSlideIn 0.3s ease",
  });
  document.body.appendChild(t);
  setTimeout(() => t.remove(), duration);
}

//  Utility

function _delay(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

// (EMOTION_COLORS defined at top of file)

//  Global Exports
window.launchInterview = launchInterview;
window.toggleCamera = toggleCamera;
window.toggleMic = toggleMic;
window.handleSetupSubmit = handleSetupSubmit;
window.joinMeeting = joinMeeting;
window.submitCurrentAnswer = submitCurrentAnswer;
window.skipQuestion = skipQuestion;
window.replayQuestion = replayQuestion;
window.confirmEndInterview = confirmEndInterview;
window.endInterview = endInterview;
window.closeModal = closeModal;
