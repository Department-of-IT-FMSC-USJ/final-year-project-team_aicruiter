import sys
import logging

logging.basicConfig(level=logging.ERROR)

def test():
    from supabase_service import _get_client
    from config import SUPABASE_BUCKET
    client = _get_client()

    out = open("upsert_results.txt", "w")

    with open("test_upsert.txt", "w") as f:
        f.write("v1")
    
    with open("test_upsert.txt", "rb") as f:
        try:
            res = client.storage.from_(SUPABASE_BUCKET).upload("test/test_upsert_3.txt", f)
            out.write(f"v1 upload: {res}\n")
        except Exception as e:
            out.write(f"v1 error: {e}\n")

    with open("test_upsert.txt", "w") as f:
        f.write("v2")

    with open("test_upsert.txt", "rb") as f:
        try:
            res2 = client.storage.from_(SUPABASE_BUCKET).upload("test/test_upsert_3.txt", f, file_options={"x-upsert": "true"})
            out.write(f"v2 upload (x-upsert=true): {res2}\n")
        except Exception as e:
            out.write(f"v2 error (x-upsert=true): {e}\n")
            
    with open("test_upsert.txt", "rb") as f:
        try:
            res3 = client.storage.from_(SUPABASE_BUCKET).upload("test/test_upsert_3.txt", f, file_options={"upsert": "true"})
            out.write(f"v2 upload (upsert=true): {res3}\n")
        except Exception as e:
            out.write(f"v2 error (upsert=true): {e}\n")

    with open("test_upsert.txt", "rb") as f:
        try:
            res4 = client.storage.from_(SUPABASE_BUCKET).update("test/test_upsert_3.txt", f)
            out.write(f"v2 update: {res4}\n")
        except Exception as e:
            out.write(f"v2 error (update): {e}\n")

    out.close()

if __name__ == "__main__":
    test()
