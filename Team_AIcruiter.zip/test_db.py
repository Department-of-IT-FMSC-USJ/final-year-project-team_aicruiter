import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent))

from supabase_service import get_all_meetings, create_meeting

print("Testing Meeting Creation...")
mid = create_meeting("Test Script Job", "Test Script JD")
if mid:
    print(f"SUCCESS: Created meeting with ID {mid}")
else:
    print("FAILED: Meeting creation failed.")

print("\nFetching all meetings...")
meets = get_all_meetings()
if meets:
    print(f"Found {len(meets)} meetings:")
    for m in meets:
        print(f" - {m.get('meeting_id')}: {m.get('job_title')}")
else:
    print("No meetings found in DB.")
