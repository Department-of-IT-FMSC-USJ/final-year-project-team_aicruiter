import sys
import logging

logging.basicConfig(level=logging.ERROR)

def test():
    from supabase_service import _get_client
    from config import SUPABASE_BUCKET
    client = _get_client()

    out = open("upsert_results_2.txt", "w")
    try:
        res = client.storage.from_(SUPABASE_BUCKET).remove(["test/test_upsert_3.txt"])
        out.write(f"remove: {res}\n")
    except Exception as e:
        out.write(f"remove error: {e}\n")

    with open("test_upsert.txt", "w") as f:
        f.write("v3")
    
    with open("test_upsert.txt", "rb") as f:
        try:
            res_upload = client.storage.from_(SUPABASE_BUCKET).upload("test/test_upsert_3.txt", f)
            out.write(f"v3 upload: {res_upload}\n")
        except Exception as e:
            out.write(f"v3 upload error: {e}\n")

    out.close()

if __name__ == "__main__":
    test()
