"""
Configuration for AI Interview System
Fill in your credentials below, or set the corresponding environment variables.
"""

import os

#  DeepSeek AI 
DEEPSEEK_API_KEY = os.environ.get("DEEPSEEK_API_KEY", "sk-1b75600d6171431a94d53cdcedf2635e")
DEEPSEEK_MODEL   = os.environ.get("DEEPSEEK_MODEL", "deepseek-chat")   # deepseek-chat | deepseek-reasoner

#  Supabase 
# Find these in: Supabase Dashboard → Project Settings → API
SUPABASE_URL = os.environ.get("SUPABASE_URL", "https://qtphfnmklqajqxpensuf.supabase.co")
SUPABASE_KEY = os.environ.get("SUPABASE_KEY", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InF0cGhmbm1rbHFhanF4cGVuc3VmIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3MTg2ODk1MCwiZXhwIjoyMDg3NDQ0OTUwfQ.Hbn6hR294jhi09VTi7LbMR_QwuzOh2HhakOG2cxKF3o")
SUPABASE_BUCKET = "interview"

#  App 
UPLOAD_FOLDER   = "uploads"
MAX_CONTENT_MB  = 16
SECRET_KEY      = os.environ.get("SECRET_KEY", "ai-interview-secret-2024")

#  Facial Analysis 
FACE_ANALYSIS_INTERVAL_SEC = 5       # Faster for live monitor feel
DEEPFACE_BACKEND            = "opencv"  # opencv | ssd | dlib | mtcnn | retinaface

#  Interview 
MAX_QUESTIONS        = 10
QUESTION_TIMEOUT_SEC = 90

#  Admin Panel 
ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "alpha123")  # Change this!
