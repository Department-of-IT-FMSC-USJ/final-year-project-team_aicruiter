-- ═══════════════════════════════════════════════════════════════════════════
-- AIcruiter — Supabase Schema
-- Run this in: Supabase Dashboard → SQL Editor → New query → Run
-- ═══════════════════════════════════════════════════════════════════════════

-- Enable UUID extension (usually already enabled in Supabase)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

--  users 
CREATE TABLE IF NOT EXISTS users (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email       TEXT UNIQUE NOT NULL,
    password    TEXT NOT NULL,            -- Hashed
    name        TEXT,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

--  candidates 
CREATE TABLE IF NOT EXISTS candidates (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name        TEXT,
    email       TEXT,
    phone       TEXT,
    job_title   TEXT,
    session_id  TEXT UNIQUE,
    meeting_id  TEXT,                     -- Link to meeting
    status      TEXT DEFAULT 'pending',   -- pending | completed
    decision    TEXT,                     -- Selected | Not Selected | On Hold
    user_id     UUID REFERENCES users(id) ON DELETE SET NULL, -- Multi-tenancy
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    updated_at  TIMESTAMPTZ DEFAULT NOW()
);

--  meetings 
CREATE TABLE IF NOT EXISTS meetings (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    meeting_id      TEXT UNIQUE NOT NULL, -- Short readable ID like 'ABCD12'
    job_title       TEXT,
    jd_text         TEXT,
    cv_text         TEXT,                 -- Pre-uploaded CV
    interview_types JSONB,                -- Selected focuses
    question_count  INTEGER DEFAULT 10,   -- Number of questions to generate
    user_id         UUID REFERENCES users(id) ON DELETE SET NULL, -- Multi-tenancy
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

--  interview_sessions 
CREATE TABLE IF NOT EXISTS interview_sessions (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    candidate_id UUID REFERENCES candidates(id) ON DELETE CASCADE,
    session_id   TEXT,
    questions    JSONB,
    qa_pairs     JSONB,
    saved_at     TIMESTAMPTZ DEFAULT NOW()
);

--  facial_analysis 
CREATE TABLE IF NOT EXISTS facial_analysis (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    candidate_id     UUID REFERENCES candidates(id) ON DELETE CASCADE,
    frames           JSONB,
    dominant_emotion TEXT,
    emotion_summary  JSONB,
    frame_count      INTEGER DEFAULT 0,
    engagement_score NUMERIC(5,2),
    confidence_score NUMERIC(5,2),
    stress_score     NUMERIC(5,2),
    estimated_age    NUMERIC(5,1),
    estimated_gender TEXT,
    recorded_at      TIMESTAMPTZ DEFAULT NOW()
);

--  final_reports 
CREATE TABLE IF NOT EXISTS final_reports (
    id                   UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    candidate_id         UUID REFERENCES candidates(id) ON DELETE CASCADE,
    decision             TEXT,
    overall_score        INTEGER,
    technical_score      INTEGER,
    communication_score  INTEGER,
    confidence_score     INTEGER,
    emotional_score      INTEGER,
    strengths            JSONB,
    improvements         JSONB,
    summary              TEXT,
    recommendation       TEXT,
    facial_summary       JSONB,
    generated_at         TIMESTAMPTZ DEFAULT NOW()
);

--  Auto-update updated_at on candidates 
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS candidates_updated_at ON candidates;
CREATE TRIGGER candidates_updated_at
    BEFORE UPDATE ON candidates
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

--  Row-Level Security (optional but recommended) 
-- If using service_role key in your backend, RLS won't block you.
-- You can enable RLS and allow the service role full access:
-- ALTER TABLE candidates       ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE interview_sessions ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE facial_analysis   ENABLE ROW LEVEL SECURITY;
-- ALTER TABLE final_reports      ENABLE ROW LEVEL SECURITY;

--  Quick verification 
SELECT 'Schema created successfully ✓' AS status;
