"""
local_test.py — Quick sanity-check that DeepSeek API and dependencies work.
Run: python local_test.py
"""
import os

#  Test DeepSeek
print("Testing DeepSeek connection...")
try:
    from openai import OpenAI
    from config import DEEPSEEK_API_KEY, DEEPSEEK_MODEL
    if not DEEPSEEK_API_KEY or DEEPSEEK_API_KEY == "your-deepseek-api-key-here":
        print("⚠️  DEEPSEEK_API_KEY not set in config.py")
    else:
        client = OpenAI(api_key=DEEPSEEK_API_KEY, base_url="https://api.deepseek.com")
        res = client.chat.completions.create(
            model=DEEPSEEK_MODEL,
            messages=[{"role": "user", "content": "Say: Ready for interviews!"}],
            max_tokens=32,
        )
        print(f"✅ DeepSeek OK: {res.choices[0].message.content.strip()}")
except Exception as e:
    print(f"❌ DeepSeek error: {e}")

#  Test Edge TTS
print("\nTesting Edge TTS...")
try:
    import asyncio, io, edge_tts
    async def _test():
        communicate = edge_tts.Communicate("Hello, I am your AI interviewer.", "en-US-AvaNeural")
        buf = io.BytesIO()
        async for chunk in communicate.stream():
            if chunk["type"] == "audio":
                buf.write(chunk["data"])
        return buf.tell()
    size = asyncio.run(_test())
    print(f"✅ Edge TTS OK — generated {size} bytes of audio")
except Exception as e:
    print(f"⚠️  Edge TTS error: {e} (gTTS fallback will be used)")

#  Test gTTS fallback
print("\nTesting gTTS fallback...")
try:
    from gtts import gTTS
    import io
    tts = gTTS("Hello, I am your AI interviewer.", lang="en")
    buf = io.BytesIO()
    tts.write_to_fp(buf)
    print(f"✅ gTTS OK — generated {buf.tell()} bytes of audio")
except Exception as e:
    print(f"❌ gTTS error: {e}")

#  Test DeepFace import
print("\nTesting DeepFace import...")
try:
    from deepface import DeepFace
    print("✅ DeepFace imported successfully")
except Exception as e:
    print(f"❌ DeepFace error: {e}")

#  Test Flask
print("\nTesting Flask import...")
try:
    from flask import Flask
    print("✅ Flask imported successfully")
except Exception as e:
    print(f"❌ Flask error: {e}")

#  Test Supabase
print("\nTesting Supabase...")
try:
    from config import SUPABASE_URL, SUPABASE_KEY
    if "YOUR-PROJECT-ID" in SUPABASE_URL or "YOUR_SUPABASE" in SUPABASE_KEY:
        print("⚠️  Supabase credentials not set in config.py — interviews will run without persistence")
    else:
        from supabase import create_client
        client = create_client(SUPABASE_URL, SUPABASE_KEY)
        print("✅ Supabase client initialised successfully")
except Exception as e:
    print(f"⚠️  Supabase: {e}")

print("\n✅ All checks complete! Run: python app.py")
