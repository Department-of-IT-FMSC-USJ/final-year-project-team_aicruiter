import sys
import os
from pathlib import Path
from flask import Flask, render_template, abort

# Add parent directory to path to import services
sys.path.append(str(Path(__file__).parent.parent))

from supabase_service import get_all_candidates, get_candidate, create_meeting, get_all_meetings
from config import SUPABASE_URL, SUPABASE_BUCKET

app = Flask(__name__)

@app.route("/")
def dashboard():
    candidates = get_all_candidates()
    # Safely sort by created_at dict
    candidates.sort(key=lambda x: x.get('created_at', ''), reverse=True)
    
    meetings = get_all_meetings()
    return render_template("index.html", candidates=candidates, meetings=meetings)

@app.route("/create-meeting", methods=["POST"])
def do_create_meeting():
    from flask import request, redirect, url_for
    title = request.form.get("job_title")
    jd = request.form.get("jd_text")
    q_count = request.form.get("question_count", type=int, default=10)
    
    # Handle focus areas
    types = request.form.getlist("interview_types")
    custom = request.form.get("custom_focus", "").strip()
    if custom:
        extra = [t.strip().upper() for t in custom.split(",") if t.strip()]
        types.extend(extra)
        
    if title and jd:
        create_meeting(title, jd, interview_types=types, question_count=q_count)
    return redirect(url_for("dashboard"))

@app.route("/candidate/<candidate_id>")
def candidate_detail(candidate_id):
    candidate = get_candidate(candidate_id)
    if not candidate:
        abort(404)
    
    # We can pass the bucket URL to construct PDF links manually if needed
    bucket_url = f"{SUPABASE_URL}/storage/v1/object/public/{SUPABASE_BUCKET}"
    return render_template("candidate.html", candidate=candidate, bucket_url=bucket_url)

if __name__ == "__main__":
    port = int(os.environ.get("ADMIN_PORT", 5001))
    print(f"Starting Admin Panel on http://localhost:{port}")
    app.run(host="0.0.0.0", port=port, debug=True)
