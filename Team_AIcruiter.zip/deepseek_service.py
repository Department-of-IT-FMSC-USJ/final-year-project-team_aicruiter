"""
DeepSeek AI service  (drop-in replacement for the former gemini_service.py)

Responsibilities
────────────────
1. Parse CV / JD text (from uploaded files)
2. Generate tailored interview questions
3. Evaluate candidate answers
4. Generate the final selection report (incorporating facial-emotion data)
5. Produce TTS audio for AI agent voice (Edge TTS → gTTS fallback)

DeepSeek exposes an OpenAI-compatible REST API, so we use the `openai` SDK
pointed at https://api.deepseek.com.
"""

import io
import os
import json
import logging
import base64
import traceback
import time
import re

from openai import OpenAI
from config import DEEPSEEK_API_KEY, DEEPSEEK_MODEL, MAX_QUESTIONS

logger = logging.getLogger(__name__)

# Client initialisation 

_client = OpenAI(
    api_key=DEEPSEEK_API_KEY,
    base_url="https://api.deepseek.com",
)

logger.info("DeepSeek client initialised. Model: %s", DEEPSEEK_MODEL)


# Helpers 
def _extract_json(text: str) -> str:
    """Robustly extract JSON from Markdown code-fence or raw text."""
    match = re.search(r'```(?:json)?\s*(.*?)\s*```', text, re.DOTALL)
    if match:
        return match.group(1).strip()
    return text.strip()


def _chat(messages: list[dict], retries: int = 3, delay: int = 10,
          temperature: float = 0.7, max_tokens: int = 4096) -> str:
    """
    Call DeepSeek chat completions with retry logic for rate-limit errors.
    Returns the assistant message content as a string.
    """
    for attempt in range(retries):
        try:
            response = _client.chat.completions.create(
                model=DEEPSEEK_MODEL,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
            )
            return response.choices[0].message.content or ""
        except Exception as e:
            err = str(e)
            is_rate_limit = "429" in err or "rate" in err.lower() or "quota" in err.lower()
            if is_rate_limit and attempt < retries - 1:
                wait = delay * (3 ** attempt)   # 10 s, 30 s, 90 s
                logger.warning("DeepSeek rate limit (attempt %d). Waiting %ds…", attempt + 1, wait)
                time.sleep(wait)
                continue
            logger.error("DeepSeek API error (attempt %d): %s", attempt + 1, err)
            raise
    return ""


# Interview type normalisation

_INTERVIEW_TYPE_ALIASES = {
    "TECH": "TECHNICAL",
    "TECHNICAL": "TECHNICAL",
    "EXPERIENCE": "EXPERIENCE",
    "BEHAVIORAL": "EXPERIENCE",
    "BEHAVIOURAL": "EXPERIENCE",
    "LEADERSHIP": "LEADERSHIP",
    "MANAGEMENT": "LEADERSHIP",
    "PROBLEM_SOLVING": "PROBLEM_SOLVING",
    "PROBLEM_SOLVING_SKILLS": "PROBLEM_SOLVING",
    "PROBLEM": "PROBLEM_SOLVING",
    "SITUATIONAL": "PROBLEM_SOLVING",
}


def _normalize_type_value(value: str) -> str:
    raw = str(value or "").strip().upper().replace("-", "_").replace(" ", "_")
    return _INTERVIEW_TYPE_ALIASES.get(raw, raw)


def _normalize_interview_types(interview_types: list | None) -> list[str]:
    if not interview_types:
        return ["TECHNICAL", "EXPERIENCE"]

    normalized: list[str] = []
    for value in interview_types:
        val_str = str(value or "").upper()
        if any(val_str.startswith(pref) for pref in ["JOBID:", "LEVEL:", "EMAIL:", "NAME:"]):
            continue
        cleaned = _normalize_type_value(value)
        if cleaned and cleaned not in normalized:
            normalized.append(cleaned)

    return normalized or ["TECHNICAL", "EXPERIENCE"]


def _build_type_distribution(selected_types: list[str], question_count: int) -> dict[str, int]:
    base = question_count // len(selected_types)
    remainder = question_count % len(selected_types)
    return {t: base + (1 if i < remainder else 0) for i, t in enumerate(selected_types)}


# Text extraction helpers

def extract_text_from_file(filepath: str) -> str:
    """Extract plain text from PDF, DOCX, or TXT files."""
    ext = os.path.splitext(filepath)[1].lower()
    try:
        if ext == ".pdf":
            import PyPDF2
            text = []
            with open(filepath, "rb") as f:
                reader = PyPDF2.PdfReader(f)
                for page in reader.pages:
                    t = page.extract_text()
                    if t:
                        text.append(t)
            return "\n".join(text)
        elif ext in (".docx", ".doc"):
            from docx import Document
            doc = Document(filepath)
            return "\n".join([p.text for p in doc.paragraphs if p.text.strip()])
        elif ext == ".txt":
            with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                return f.read()
        else:
            logger.warning("Unsupported file type: %s", ext)
            return ""
    except Exception:
        logger.error(traceback.format_exc())
        return ""


# Question generation

def generate_interview_questions(
    cv_text: str,
    jd_text: str,
    interview_types: list = None,
    question_count: int = None,
    job_level: str = "Associate",
) -> list[dict]:
    """
    Return a list of question dicts:
        [{"id": 1, "question": "...", "question_type": "TECHNICAL", "category": "technical"}]
    """
    try:
        count = int(question_count or MAX_QUESTIONS)
    except Exception:
        count = MAX_QUESTIONS
    count = max(1, min(count, 25))

    selected_types = _normalize_interview_types(interview_types)
    distribution = _build_type_distribution(selected_types, count)

    type_list = ", ".join(selected_types)
    distribution_text = "\n".join(
        f"- {t}: {distribution[t]}" for t in selected_types
    )

    if len(cv_text.strip()) < 10:
        raise ValueError("CV text is empty — please upload a text-based PDF, not a scanned image.")
    if len(jd_text.strip()) < 10:
        raise ValueError("Job Description text is empty — please provide readable JD text.")

    prompt = f"""You are an expert HR interviewer and technical recruiter.

Your task is to conduct a professional, deep-dive interview for a {job_level} level position.
Create exactly {count} interview questions that strictly map the candidate's CV to the Job Description (JD), tailored for the {job_level} seniority.

Selected interview type categories (MUST be used as question_type values): {type_list}

Required question distribution across selected categories:
{distribution_text}

Focus on:
1. Identifying gaps between their experience and the JD requirements.
2. Asking for specific examples from listed projects/experience that prove they can handle JD responsibilities.
3. Type-specific depth according to selected categories.

Return your response as a JSON array ONLY — no markdown, no explanation — with this structure:
[
  {{"id": 1, "question": "...", "question_type": "TECHNICAL", "category": "technical"}},
  ...
]

Rules:
- question_type MUST be one of: {type_list}
- Respect the distribution exactly.
- category should be lowercase version of question_type.
- Keep questions concrete and directly tied to CV + JD context.

=== CANDIDATE CV ===
{cv_text[:5000]}

=== JOB DESCRIPTION ===
{jd_text[:3000]}"""

    try:
        raw = _chat(
            [{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=4096,
        )
        logger.info("DeepSeek question generation response (first 300): %s", raw[:300])
        parsed_json_str = _extract_json(raw)

        raw_questions = json.loads(parsed_json_str)
        if not isinstance(raw_questions, list):
            raise ValueError("DeepSeek returned non-array JSON")

        normalized_questions: list[dict] = []
        remaining = dict(distribution)

        def _next_type_with_capacity() -> str:
            for t in selected_types:
                if remaining.get(t, 0) > 0:
                    return t
            return selected_types[0]

        for item in raw_questions:
            if len(normalized_questions) >= count:
                break
            if not isinstance(item, dict):
                continue

            question_text = str(item.get("question", "")).strip()
            if not question_text:
                continue

            raw_type = item.get("question_type") or item.get("category")
            normalized_type = _normalize_type_value(str(raw_type or ""))

            if normalized_type not in selected_types or remaining.get(normalized_type, 0) <= 0:
                normalized_type = _next_type_with_capacity()

            remaining[normalized_type] = max(remaining.get(normalized_type, 0) - 1, 0)

            normalized_questions.append({
                "id": len(normalized_questions) + 1,
                "question": question_text,
                "question_type": normalized_type,
                "category": normalized_type.lower(),
            })

        # Fill any shortfall with generic fallback questions
        while len(normalized_questions) < count:
            fallback_type = _next_type_with_capacity()
            remaining[fallback_type] = max(remaining.get(fallback_type, 0) - 1, 0)
            normalized_questions.append({
                "id": len(normalized_questions) + 1,
                "question": (
                    "Can you share a concrete example from your background that demonstrates "
                    f"your {fallback_type.replace('_', ' ').lower()} capability for this role?"
                ),
                "question_type": fallback_type,
                "category": fallback_type.lower(),
            })

        logger.info(
            "Generated %d questions with types: %s",
            len(normalized_questions),
            ", ".join(selected_types),
        )
        return normalized_questions

    except json.JSONDecodeError:
        logger.error("JSON parse failed. Raw response: %s", raw)
        raise ValueError(f"DeepSeek returned non-JSON response: {raw[:200]}")
    except ValueError:
        raise
    except Exception as e:
        logger.error("DeepSeek question generation failed: %s\n%s", e, traceback.format_exc())
        raise ValueError(f"DeepSeek API error: {e}")


#  Answer evaluation 

def evaluate_answer(question: str, answer: str, cv_text: str, jd_text: str) -> dict:
    """Score a single answer 0-10 and return brief feedback."""
    prompt = f"""You are a senior interviewer evaluating a candidate's answer.

Question: {question}
Candidate's Answer: {answer}

Context (brief):
CV summary: {cv_text[:800]}
Job role: {jd_text[:500]}

Evaluate the answer on:
- Relevance (0-10)
- Depth & clarity (0-10)
- Confidence (inferred from text, 0-10)

Return JSON ONLY (no markdown):
{{"overall_score": <0-10>, "relevance": <0-10>, "depth": <0-10>, "confidence": <0-10>, "feedback": "<one sentence>"}}"""

    try:
        raw = _chat(
            [{"role": "user", "content": prompt}],
            temperature=0.3,
            max_tokens=256,
        )
        return json.loads(_extract_json(raw))
    except Exception as e:
        logger.error("Answer evaluation failed: %s", e)
        return {"overall_score": 5, "relevance": 5, "depth": 5, "confidence": 5, "feedback": "Answer received."}


#  Final decision report 

def generate_final_report(
    candidate_info: dict,
    jd_text: str,
    qa_pairs: list[dict],
    facial_summary: dict,
) -> dict:
    """
    Produce a structured final report and hiring decision.

    Returns:
        {
          "decision": "Recommended" | "Not Recommended",
          "overall_score": 0-100,
          "technical_score": 0-100,
          "communication_score": 0-100,
          "confidence_score": 0-100,
          "emotional_score": 0-100,
          "strengths": [...],
          "improvements": [...],
          "summary": "...",
          "recommendation": "..."
        }
    """
    qa_text = "\n".join(
        f"Q{i+1}: {qa['question']}\nA: {qa.get('answer', '(no answer)')}\n"
        f"Score: {qa.get('score', {}).get('overall_score', 'N/A')}/10"
        for i, qa in enumerate(qa_pairs)
    )
    emotion_text = json.dumps(facial_summary, indent=2) if facial_summary else "Not available"

    prompt = f"""You are a senior HR director making a final hiring decision.

=== CANDIDATE INFO ===
Name: {candidate_info.get('name', 'Unknown')}
Email: {candidate_info.get('email', '')}
Applied for: {candidate_info.get('job_title', '')}

=== JOB DESCRIPTION ===
{jd_text[:1500]}

=== INTERVIEW Q&A WITH SCORES ===
{qa_text}

=== FACIAL EMOTION ANALYSIS DURING INTERVIEW ===
{emotion_text}

Based on ALL of the above, provide a comprehensive hiring assessment.
Return ONLY valid JSON (no markdown, no extra text):
{{
  "decision": "Recommended" or "Not Recommended",
  "overall_score": <0-100>,
  "technical_score": <0-100>,
  "communication_score": <0-100>,
  "confidence_score": <0-100>,
  "emotional_score": <0-100>,
  "strengths": ["...", "..."],
  "improvements": ["...", "..."],
  "summary": "<3-4 sentence executive summary>",
  "recommendation": "<actionable next step>"
}}"""

    try:
        raw = _chat(
            [{"role": "user", "content": prompt}],
            temperature=0.4,
            max_tokens=1024,
        )
        report = json.loads(_extract_json(raw))
        logger.info("Final report generated. Decision: %s", report.get("decision"))
        return report
    except Exception as e:
        logger.error("Failed to generate final report: %s\n%s", e, traceback.format_exc())
        return {
            "decision": "Not Recommended",
            "overall_score": 0,
            "technical_score": 0,
            "communication_score": 0,
            "confidence_score": 0,
            "emotional_score": 0,
            "strengths": ["Interview completed"],
            "improvements": ["Further evaluation needed"],
            "summary": "The interview was completed. Manual review recommended.",
            "recommendation": "Schedule a follow-up interview.",
        }


#  Text-to-Speech 

def text_to_speech_base64(text: str, lang: str = "en") -> str:
    """
    Convert text to speech using Edge TTS (en-US-AvaNeural).
    Falls back to gTTS, then returns empty string (browser SpeechSynthesis fallback).
    """
    import asyncio
    import edge_tts

    VOICE = "en-US-AvaNeural"

    async def _generate_edge():
        communicate = edge_tts.Communicate(text, VOICE)
        buf = io.BytesIO()
        async for chunk in communicate.stream():
            if chunk["type"] == "audio":
                buf.write(chunk["data"])
        buf.seek(0)
        return base64.b64encode(buf.read()).decode("utf-8")

    try:
        return asyncio.run(asyncio.wait_for(_generate_edge(), timeout=5.0))
    except Exception as e:
        logger.warning("Edge-TTS failed: %s. Falling back to gTTS.", e)

    try:
        from gtts import gTTS
        tts = gTTS(text=text, lang=lang, slow=False)
        buf = io.BytesIO()
        tts.write_to_fp(buf)
        buf.seek(0)
        return base64.b64encode(buf.read()).decode("utf-8")
    except Exception:
        logger.warning("gTTS also failed. Browser will handle TTS.")
        return ""


#  Contextual follow-up 

def get_follow_up_or_next(
    previous_answer: str,
    current_question: str,
    remaining_questions: int,
) -> str | None:
    """
    Optionally generate a short follow-up probe if the answer is vague.
    Returns None if no follow-up is warranted.
    """
    if not previous_answer.strip() or remaining_questions <= 1:
        return None

    prompt = f"""A candidate just gave this answer to a question.

Question: {current_question}
Answer: {previous_answer}

If the answer is vague, too short, or avoids the required technical depth, write a sharp investigative follow-up question (max 20 words).
If the answer is comprehensive and high-quality, respond with exactly: NO_FOLLOWUP"""

    try:
        result = _chat(
            [{"role": "user", "content": prompt}],
            temperature=0.5,
            max_tokens=60,
        ).strip()
        if "NO_FOLLOWUP" in result:
            return None
        return result[:200]
    except Exception:
        return None
