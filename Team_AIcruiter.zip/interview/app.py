"""
AI Interview System — Flask Backend
=====================================
Routes
------
POST /api/upload          — Upload CV + JD, create candidate, generate questions
GET  /api/questions/<id>  — Return generated questions for a session
POST /api/analyse-frame   — Receive a webcam frame, run facial analysis
POST /api/submit-answer   — Save a candidate's spoken/typed answer + score it
POST /api/end-interview   — Finalise session, generate report, persist to Supabase
GET  /api/report/<id>     — Retrieve completed report
GET  /api/candidates      — List all candidates (admin)
POST /api/tts             — Convert text to speech (base64 MP3)
"""

import os
import uuid
import json
import logging
import traceback
from pathlib import Path
from functools import wraps
from flask import Flask, request, jsonify, send_from_directory, render_template, redirect, url_for, Response
from flask_cors import CORS

from config import UPLOAD_FOLDER, MAX_CONTENT_MB, SECRET_KEY, ADMIN_USERNAME, ADMIN_PASSWORD, SUPABASE_URL, SUPABASE_BUCKET

#  App setup 
app = Flask(__name__, static_folder="static", static_url_path="")
app.secret_key = SECRET_KEY
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_MB * 1024 * 1024
CORS(app, origins="*")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

Path(UPLOAD_FOLDER).mkdir(exist_ok=True)

# In-memory session store (persisted to Firebase at end)
# { session_id: { candidate_id, cv_text, jd_text, questions, qa_pairs, ... } }
_sessions: dict[str, dict] = {}

ALLOWED_EXT = {".pdf", ".docx", ".doc", ".txt"}


def _allowed(filename: str) -> bool:
    return Path(filename).suffix.lower() in ALLOWED_EXT


#  Auth Decorator 

def check_auth(username, password):
    return username == ADMIN_USERNAME and password == ADMIN_PASSWORD

def authenticate():
    return Response(
        'Could not verify your access level for that URL.\n'
        'You have to login with proper credentials', 401,
        {'WWW-Authenticate': 'Basic realm="Login Required"'}
    )

def requires_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.authorization
        if not auth or not check_auth(auth.username, auth.password):
            return authenticate()
        return f(*args, **kwargs)
    return decorated


def _session(sid: str) -> dict | None:
    return _sessions.get(sid)


#  Serve frontend 

@app.route("/")
def index():
    return send_from_directory("static", "index.html")


#  Admin Routes 

@app.route("/admin")
@requires_auth
def admin_dashboard():
    from supabase_service import get_all_candidates, get_all_meetings
    candidates = get_all_candidates()
    # Safely sort by created_at dict
    candidates.sort(key=lambda x: x.get('created_at', ''), reverse=True)
    meetings = get_all_meetings()
    
    # Get the actual base URL (e.g. https://domain.com)
    base_url = request.host_url.rstrip('/')
    
    # Point to the admin template subfolder
    return render_template("admin/index.html", 
                         candidates=candidates, 
                         meetings=meetings, 
                         base_url=base_url)


@app.route("/admin/candidate/<candidate_id>")
@requires_auth
def admin_candidate_detail(candidate_id):
    from supabase_service import get_candidate, get_meeting
    candidate = get_candidate(candidate_id)
    if not candidate:
        return "Candidate not found", 404
    
    bucket_url = f"{SUPABASE_URL}/storage/v1/object/public/{SUPABASE_BUCKET}"
    
    # Resolve CV and JD URLs
    # Base paths
    cv_url = f"{bucket_url}/{candidate.get('id')}/cv.pdf"
    jd_url = f"{bucket_url}/{candidate.get('id')}/jd.pdf"
    
    meeting_id = candidate.get("meeting_id")
    if meeting_id:
        # JD and CV are in meetings/ID/ if admin uploaded them
        jd_url = f"{bucket_url}/meetings/{meeting_id}/jd.pdf"
        cv_url = f"{bucket_url}/meetings/{meeting_id}/cv.pdf"

    return render_template("admin/candidate.html", 
                         candidate=candidate, 
                         bucket_url=bucket_url,
                         cv_url=cv_url,
                         jd_url=jd_url)


@app.route("/admin/create-meeting", methods=["POST"])
@requires_auth
def admin_create_meeting():
    from supabase_service import create_meeting, upload_document
    from deepseek_service import extract_text_from_file
    
    title = request.form.get("job_title")
    jd_text = request.form.get("jd_text", "").strip()
    interview_types = request.form.getlist("interview_types")
    
    cv_file = request.files.get("cv_file")
    jd_file = request.files.get("jd_file")
    
    if not cv_file or not cv_file.filename:
        return jsonify({"success": False, "error": "Candidate CV is required"}), 400
        
    try:
        temp_id = str(uuid.uuid4())
        session_dir = Path(UPLOAD_FOLDER) / temp_id
        session_dir.mkdir(parents=True, exist_ok=True)
        
        # ── Handle CV
        cv_ext = Path(cv_file.filename).suffix.lower()
        cv_path = session_dir / f"cv{cv_ext}"
        cv_file.save(cv_path)
        cv_text = extract_text_from_file(str(cv_path))
        
        if not cv_text.strip() or len(cv_text.strip()) < 50:
             return jsonify({"success": False, "error": "Could not extract sufficient text from Candidate CV. Please ensure it is a text-based PDF (not an image)."}), 400

        # ── Handle JD
        if jd_file and jd_file.filename:
            jd_ext = Path(jd_file.filename).suffix.lower()
            jd_path = session_dir / f"jd{jd_ext}"
            jd_file.save(jd_path)
            extracted_jd = extract_text_from_file(str(jd_path))
            if extracted_jd.strip():
                jd_text = extracted_jd
        
        if not jd_text.strip() or len(jd_text.strip()) < 20:
            return jsonify({"success": False, "error": "Job Description text is missing or unreadable. Please provide a clear JD to generate relevant questions."}), 400

        # ── Create Meeting
        meeting_id = create_meeting(title, jd_text, cv_text, interview_types)
        
        if meeting_id:
            # Persistent Storage for Admin visibility
            upload_document(str(cv_path), f"meetings/{meeting_id}/cv{cv_ext}")
            if jd_file and jd_file.filename:
                upload_document(str(jd_path), f"meetings/{meeting_id}/jd{jd_ext}")
                
            return jsonify({"success": True, "meeting_id": meeting_id})
        
        return jsonify({"success": False, "error": "Database error"}), 500
        
    except Exception as e:
        logger.error(traceback.format_exc())
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/admin/delete-candidate/<candidate_id>", methods=["DELETE"])
@requires_auth
def api_delete_candidate(candidate_id):
    from supabase_service import delete_candidate
    if delete_candidate(candidate_id):
        return jsonify({"success": True})
    return jsonify({"success": False, "error": "Delete failed"}), 500


@app.route("/api/admin/delete-meeting/<meeting_id>", methods=["DELETE"])
@requires_auth
def api_delete_meeting(meeting_id):
    from supabase_service import delete_meeting
    if delete_meeting(meeting_id):
        return jsonify({"success": True})
    return jsonify({"success": False, "error": "Delete failed"}), 500


@app.route("/api/admin/dashboard-stats")
@requires_auth
def api_dashboard_stats():
    from supabase_service import get_all_candidates, get_all_meetings
    candidates = get_all_candidates()
    meetings = get_all_meetings()
    
    completed = [c for c in candidates if c.get("status") == "completed"]
    selected = [c for c in candidates if c.get("decision") == "Selected"]
    
    return jsonify({
        "total_candidates": len(candidates),
        "total_meetings": len(meetings),
        "total_completed": len(completed),
        "total_hired": len(selected)
    })


@app.route("/<path:path>")
def static_files(path):
    return send_from_directory("static", path)


#  /api/upload 

# Global store for live frame viewing (admin)
_live_frames = {}

@app.route("/api/meeting/<meeting_id>", methods=["GET"])
def get_meeting_details(meeting_id: str):
    from supabase_service import get_meeting
    meeting = get_meeting(meeting_id)
    if not meeting:
        return jsonify({"error": "Meeting link invalid or expired."}), 404
    return jsonify(meeting)

@app.route("/api/upload", methods=["POST"])
def upload():
    """
    Expects multipart/form-data with:
      - name, email, phone (form fields)
      - meeting_id (REQUIRED)
    """
    try:
        from deepseek_service import generate_interview_questions
        from supabase_service import create_candidate, get_meeting

        meeting_id = request.form.get("meeting_id")
        if not meeting_id:
            return jsonify({"error": "Meeting ID is required to start the interview."}), 400
            
        mtg = get_meeting(meeting_id)
        if not mtg:
            return jsonify({"error": "Invalid or unavailable Meeting ID. Please check your link."}), 404
            
        jd_text = mtg.get("jd_text", "")
        cv_text = mtg.get("cv_text", "")
        job_title = mtg.get("job_title", "")
        interview_types = mtg.get("interview_types", [])

        if not cv_text or not jd_text:
             return jsonify({"error": "This meeting is not fully configured (missing CV or JD)."}), 400

        #  candidate info
        session_id = str(uuid.uuid4())
        candidate_data = {
            "name":       request.form.get("name", ""),
            "email":      request.form.get("email", ""),
            "phone":      request.form.get("phone", ""),
            "job_title":  job_title,
            "session_id": session_id,
            "meeting_id": meeting_id
        }

        if not candidate_data["name"] or not candidate_data["email"]:
            return jsonify({"error": "Name and Email are required to proceed."}), 400

        #  generate questions
        logger.info("Generating questions for meeting %s…", meeting_id)
        questions = generate_interview_questions(cv_text, jd_text, interview_types)

        #  store in Supabase
        candidate_id = create_candidate(candidate_data) or session_id

        #  store in memory
        _sessions[session_id] = {
            "session_id":   session_id,
            "candidate_id": candidate_id,
            "candidate":    candidate_data,
            "cv_text":      cv_text,
            "jd_text":      jd_text,
            "questions":    questions,
            "qa_pairs":     [],
            "current_q":    0,
            "facial_frames": [],
        }

        return jsonify({
            "success": True,
            "session_id": session_id,
            "candidate_id": candidate_id,
            "candidate": candidate_data,
            "questions": questions
        })

    except Exception as e:
        logger.error(traceback.format_exc())
        return jsonify({"error": str(e)}), 500

        logger.info("Session %s created — %d questions", session_id, len(questions))
        return jsonify({
            "session_id":   session_id,
            "candidate_id": candidate_id,
            "question_count": len(questions),
            "candidate":    candidate_data,
        })

    except ValueError as e:
        logger.error(str(e))
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        logger.error(traceback.format_exc())
        return jsonify({"error": f"Internal server error: {str(e)}"}), 500


#  /api/questions/<session_id> 

@app.route("/api/questions/<session_id>", methods=["GET"])
def get_questions(session_id: str):
    sess = _session(session_id)
    if not sess:
        return jsonify({"error": "Session not found"}), 404
    return jsonify({
        "questions": sess["questions"],
        "current_q": sess["current_q"],
    })


#  /api/next-question 

@app.route("/api/next-question/<session_id>", methods=["GET"])
def next_question(session_id: str):
    sess = _session(session_id)
    if not sess:
        return jsonify({"error": "Session not found"}), 404

    from deepseek_service import text_to_speech_base64

    # Use a separate state variable to track the "pending" question index
    # to avoid skipping if front-end calls this multiple times
    idx = sess.get("current_q", 0)
    questions = sess.get("questions", [])

    if idx >= len(questions):
        logger.info("Session %s: All questions completed.", session_id)
        return jsonify({"done": True})

    q = questions[idx]
    logger.info("Session %s: Serving question %d: %s", session_id, idx, q["question"][:50])

    # Pre-generate TTS audio
    audio_b64 = text_to_speech_base64(q["question"])
    
    # Increment pointer only AFTER we are sure we are serving it
    sess["current_q"] = idx + 1

    return jsonify({
        "done":     False,
        "index":    idx,
        "question": q,
        "audio":    audio_b64,
        "total":    len(questions),
    })


#  /api/submit-answer 

@app.route("/api/submit-answer", methods=["POST"])
def submit_answer():
    data = request.get_json(force=True)
    session_id = data.get("session_id")
    sess = _session(session_id)
    if not sess:
        return jsonify({"error": "Session not found"}), 404

    from deepseek_service import evaluate_answer, text_to_speech_base64

    q_index  = data.get("question_index", 0)
    answer   = data.get("answer", "").strip()
    questions = sess["questions"]

    if q_index >= len(questions):
        return jsonify({"error": "Invalid question index"}), 400

    question_text = questions[q_index]["question"]

    # Score the answer
    score = evaluate_answer(question_text, answer, sess["cv_text"], sess["jd_text"])

    pair = {
        "question_index": q_index,
        "question":       question_text,
        "answer":         answer,
        "score":          score,
    }
    sess["qa_pairs"].append(pair)

    # ── Check for dynamic follow-up probe (EQ feature- limit to 1 per question)
    from deepseek_service import get_follow_up_or_next
    remaining = len(sess["questions"]) - sess["current_q"]
    
    # Track follow-up status in session
    follow_up_count = sess.get("follow_up_count", 0)
    follow_up = None
    
    # Allow up to 2 investigative follow-ups per main question
    if follow_up_count < 2:
        follow_up = get_follow_up_or_next(answer, question_text, remaining)
    
    if follow_up:
        sess["follow_up_count"] = follow_up_count + 1
    else:
        sess["follow_up_count"] = 0 # reset for next question
    
    follow_up_audio = None
    if follow_up:
        logger.info("Session %s: Generated follow-up: %s", session_id, follow_up)
        follow_up_audio = text_to_speech_base64(follow_up)

    # Acknowledgement TTS (if no follow up)
    ack_audio = None
    ack_text = ""
    if not follow_up:
        ack_messages = [
            "Thank you for your answer. Let's continue.",
            "Interesting response! Moving on.",
            "Got it, thank you. Next question.",
            "Thank you. Here comes the next question.",
        ]
        import random
        ack_text = random.choice(ack_messages)
        ack_audio = text_to_speech_base64(ack_text)

    return jsonify({
        "score":           score,
        "ack_audio":       ack_audio,
        "ack_text":        ack_text,
        "follow_up":       follow_up,
        "follow_up_audio": follow_up_audio
    })


#  /api/analyse-frame 

@app.route("/api/analyse-frame", methods=["POST"])
def analyse_frame():
    data = request.get_json(force=True)
    session_id = data.get("session_id")
    frame_b64  = data.get("frame")     # data-URL or raw base64

    if not session_id or not frame_b64:
        return jsonify({"error": "Missing session_id or frame"}), 400

    # Store for live viewing with timestamp
    import time
    _live_frames[session_id] = {
        "frame": frame_b64,
        "last_seen": time.time()
    }

    from facial_analysis import analyse_frame as af
    result = af(frame_b64, session_id)
    return jsonify(result)

@app.route("/api/live-frame/<session_id>", methods=["GET"])
def get_live_frame(session_id: str):
    data = _live_frames.get(session_id)
    if not data:
        return jsonify({"error": "No frame available"}), 404
    # Check if it's a dict or old format string
    if isinstance(data, dict):
        return jsonify({"frame": data["frame"]})
    return jsonify({"frame": data})

@app.route("/api/active-sessions", methods=["GET"])
def get_active_sessions():
    """Returns a list of session_ids that have sent a frame in the last 60 seconds."""
    import time
    now = time.time()
    active = []
    for sid, data in _live_frames.items():
        if isinstance(data, dict):
            if now - data.get("last_seen", 0) < 60:
                active.append(sid)
    return jsonify({"active_sessions": active})


#  /api/end-interview 

@app.route("/api/end-interview", methods=["POST"])
def end_interview():
    data = request.get_json(force=True)
    session_id = data.get("session_id")
    sess = _session(session_id)
    if not sess:
        return jsonify({"error": "Session not found"}), 404

    from deepseek_service import generate_final_report, text_to_speech_base64
    from facial_analysis import get_emotion_summary, get_session_frames, clear_session
    from supabase_service import save_facial_data, save_interview_session, save_final_report

    candidate_id = sess["candidate_id"]
    facial_frames = get_session_frames(session_id)
    facial_summary = get_emotion_summary(session_id)

    #  Persist facial data
    save_facial_data(candidate_id, facial_frames)

    #  Persist QA session
    save_interview_session(candidate_id, {
        "questions":  sess["questions"],
        "qa_pairs":   sess["qa_pairs"],
        "session_id": session_id,
    })

    #  Generate final AI report
    logger.info("Generating final report for session %s…", session_id)
    report = generate_final_report(
        candidate_info=sess["candidate"],
        jd_text=sess["jd_text"],
        qa_pairs=sess["qa_pairs"],
        facial_summary=facial_summary,
    )
    report["facial_summary"] = facial_summary
    report["candidate"]      = sess["candidate"]

    #  Persist report
    save_final_report(candidate_id, report)

    #  TTS closing statement
    decision = report.get("decision", "On Hold")
    closing_map = {
        "Selected":     "Congratulations! Based on your interview performance and our analysis, we are pleased to move forward. You did great!",
        "Not Selected": "Thank you for your time today. We appreciate your effort during the interview and will keep your details on file.",
        "On Hold":      "Thank you for participating in this interview. We will review your application and get back to you shortly.",
    }
    closing_text = closing_map.get(decision, closing_map["On Hold"])
    closing_audio = text_to_speech_base64(closing_text)

    #  Clean up
    clear_session(session_id)
    _sessions.pop(session_id, None)

    return jsonify({
        "report":        report,
        "closing_text":  closing_text,
        "closing_audio": closing_audio,
        "candidate_id":  candidate_id,
    })


#  /api/report/<candidate_id> 

@app.route("/api/report/<candidate_id>", methods=["GET"])
def get_report(candidate_id: str):
    from supabase_service import get_candidate
    data = get_candidate(candidate_id)
    if not data:
        return jsonify({"error": "Candidate not found"}), 404
    return jsonify(data)


#  /api/candidates 

@app.route("/api/candidates", methods=["GET"])
def list_candidates():
    from supabase_service import get_all_candidates
    candidates = get_all_candidates()
    return jsonify({"candidates": candidates, "count": len(candidates)})


#  /api/tts 

@app.route("/api/tts", methods=["POST"])
def tts():
    data = request.get_json(force=True)
    text = data.get("text", "")
    if not text:
        return jsonify({"error": "No text provided"}), 400
    from deepseek_service import text_to_speech_base64
    audio = text_to_speech_base64(text)
    return jsonify({"audio": audio})


#  /api/health 

@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "active_sessions": len(_sessions)})


#  Entry point 

if __name__ == "__main__":
    import os
    port = int(os.environ.get("PORT", 7860))
    logger.info(f"Starting AI Interview System on http://0.0.0.0:{port}")
    app.run(debug=False, host="0.0.0.0", port=port, threaded=True)
