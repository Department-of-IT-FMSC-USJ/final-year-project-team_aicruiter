"""
Supabase service — replaces firebase_service.py

Stores candidate info, interview sessions, facial analysis,
and final AI hiring reports in Supabase Postgres.

Tables (see supabase_schema.sql):
  candidates            — core profile + decision status
  interview_sessions    — all Q&A pairs with scores
  facial_analysis       — per-session emotion frame data
  final_reports         — Gemini's final evaluation report
"""

import logging
import traceback
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

_client = None
_supabase_available = False


#  Lazy initialisation 

def _get_client():
    """Return a Supabase client, initialising it on first call."""
    global _client, _supabase_available

    if _client is not None:
        return _client

    try:
        from supabase import create_client, Client
        from config import SUPABASE_URL, SUPABASE_KEY

        if "YOUR-PROJECT-ID" in SUPABASE_URL or "YOUR_SUPABASE" in SUPABASE_KEY:
            logger.warning(
                "Supabase credentials not set in config.py — "
                "interview data will NOT be persisted."
            )
            return None

        _client = create_client(SUPABASE_URL, SUPABASE_KEY)
        _supabase_available = True
        logger.info("Supabase client initialised successfully.")
        return _client

    except Exception as exc:
        logger.error("Supabase init failed: %s", exc)
        return None


def _ts() -> str:
    return datetime.now(timezone.utc).isoformat()


def upload_document(local_path: str, remote_path: str) -> str | None:
    """Upload a file to the Supabase storage bucket defined in config."""
    client = _get_client()
    if client is None:
        return None

    try:
        from config import SUPABASE_BUCKET
        with open(local_path, "rb") as f:
            # We use opsert=True in case the user re-uploads or session resumes
            # Newer supabase-py uses 'options' but many still use 'file_options'
            try:
                client.storage.from_(SUPABASE_BUCKET).upload(
                    path=remote_path,
                    file=f,
                    options={"upsert": "true"}
                )
            except:
                # Fallback for older library versions
                client.storage.from_(SUPABASE_BUCKET).upload(
                    path=remote_path,
                    file=f,
                    file_options={"upsert": "true"}
                )
        return client.storage.from_(SUPABASE_BUCKET).get_public_url(remote_path)
    except Exception as e:
        logger.error("Storage upload failed: %s", e)
        return None


#  Candidates 

def create_candidate(candidate_data: dict) -> str | None:
    """
    Insert a new candidate row and return its UUID.
    Returns None if Supabase isn't configured.
    """
    client = _get_client()
    if client is None:
        return None

    try:
        payload = {
            "name":       candidate_data.get("name", ""),
            "email":      candidate_data.get("email", ""),
            "phone":      candidate_data.get("phone", ""),
            "job_title":  candidate_data.get("job_title", ""),
            "session_id": candidate_data.get("session_id", ""),
            "meeting_id": candidate_data.get("meeting_id", ""),
            "status":     "pending",
        }
        
        res = client.table("candidates").insert(payload).execute()
        if not res.data:
            logger.error("Supabase insert returned no data. Check table permissions/RLS.")
            return None
            
        candidate_id = res.data[0]["id"]
        logger.info("Candidate created successfully: %s", candidate_id)
        return candidate_id

    except Exception as e:
        logger.error("Failed to create candidate in Supabase: %s", str(e))
        logger.error(traceback.format_exc())
        return None


#  Meetings 

def create_meeting(job_title: str, jd_text: str, cv_text: str = "", interview_types: list = None) -> str | None:
    """Create a new interview session JD and return a short meeting ID."""
    client = _get_client()
    if client is None: 
        print("DEBUG: create_meeting - client is None")
        return None
    
    import uuid
    meeting_id = str(uuid.uuid4()).split("-")[0].upper()
    try:
        payload = {
            "meeting_id":      meeting_id,
            "job_title":       job_title,
            "jd_text":         jd_text,
            "cv_text":         cv_text,
            "interview_types": interview_types or ["TECHNICAL"]
        }
        res = client.table("meetings").insert(payload).execute()
        print(f"DEBUG: create_meeting - Inserted: {res.data}")
        return meeting_id
    except Exception as e:
        print(f"DEBUG: create_meeting error: {e}")
        logger.error(traceback.format_exc())
        return None

def get_meeting(meeting_id: str) -> dict | None:
    """Fetch meeting details by its short ID."""
    client = _get_client()
    if client is None: return None
    try:
        res = client.table("meetings").select("*").eq("meeting_id", meeting_id).maybe_single().execute()
        return res.data
    except Exception:
        logger.error(traceback.format_exc())
        return None

def get_all_meetings() -> list:
    """Fetch all scheduled meetings."""
    client = _get_client()
    if client is None: 
        print("DEBUG: get_all_meetings - client is None")
        return []
    try:
        res = client.table("meetings").select("*").order("created_at", desc=True).execute()
        print(f"DEBUG: get_all_meetings - Count: {len(res.data) if res.data else 0}")
        return res.data or []
    except Exception as e:
        print(f"DEBUG: get_all_meetings error: {e}")
        logger.error(traceback.format_exc())
        return []


def update_candidate(candidate_id: str, data: dict) -> bool:
    client = _get_client()
    if client is None:
        return False
    try:
        client.table("candidates").update(data).eq("id", candidate_id).execute()
        return True
    except Exception:
        logger.error(traceback.format_exc())
        return False


def get_candidate(candidate_id: str) -> dict | None:
    client = _get_client()
    if client is None:
        return None
    try:
        res = (
            client.table("candidates")
            .select(
                "*, interview_sessions(*), facial_analysis(*), final_reports(*)"
            )
            .eq("id", candidate_id)
            .maybe_single()
            .execute()
        )
        return res.data
    except Exception:
        logger.error(traceback.format_exc())
        return None


def get_all_candidates() -> list:
    client = _get_client()
    if client is None:
        return []
    try:
        res = (
            client.table("candidates")
            .select("*")
            .order("created_at", desc=True)
            .execute()
        )
        data = res.data or []

        # Add a `position_title` derived from the meeting if available
        for c in data:
            meeting_id = c.get("meeting_id")
            position = ""
            if meeting_id:
                try:
                    meeting = get_meeting(meeting_id)
                    if meeting:
                        position = (meeting.get("job_title") or "").strip()
                except Exception:
                    logger.debug("Enrichment failed for candidate %s", c.get("id"))
            c["position_title"] = position or (c.get("job_title") or "").strip() or "N/A"

        return data
    except Exception:
        logger.error(traceback.format_exc())
        return []


#  Facial analysis 

def save_facial_data(candidate_id: str, analysis_list: list) -> bool:
    """
    Upsert the facial analysis for a candidate session.
    Heavy per-frame data is stored as JSONB; derived scores go in columns.
    """
    client = _get_client()
    if client is None:
        return False

    try:
        # Aggregate
        emotion_totals: dict = {}
        age_sum = 0
        age_count = 0
        gender_votes: dict = {}
        valid = 0

        for frame in analysis_list:
            emotions = frame.get("emotions") or {}
            if not emotions:
                continue
            valid += 1
            for emotion, score in emotions.items():
                emotion_totals[emotion] = emotion_totals.get(emotion, 0) + score
            if frame.get("age"):
                age_sum += frame["age"]
                age_count += 1
            gender = frame.get("gender")
            if gender:
                gender_votes[gender] = gender_votes.get(gender, 0) + 1

        if valid > 0:
            avg_emotions = {k: round(v / valid, 2) for k, v in emotion_totals.items()}
            dominant = max(avg_emotions, key=avg_emotions.get) if avg_emotions else "neutral"
            engagement = min(round((avg_emotions.get("happy", 0) + avg_emotions.get("surprise", 0) * 0.5) * 1.2, 1), 100)
            confidence = max(round(100 - (avg_emotions.get("fear", 0) + avg_emotions.get("sad", 0) + avg_emotions.get("disgust", 0)) / 3, 1), 0)
            stress     = min(round((avg_emotions.get("fear", 0) + avg_emotions.get("angry", 0) + avg_emotions.get("disgust", 0)) / 3, 1), 100)
        else:
            avg_emotions, dominant, engagement, confidence, stress = {}, "neutral", 0, 50, 0

        payload = {
            "candidate_id":     candidate_id,
            # Store only up to 200 frames to stay within Supabase 1 MB cell limit
            "frames":           analysis_list[:200],
            "dominant_emotion": dominant,
            "emotion_summary":  avg_emotions,
            "frame_count":      len(analysis_list),
            "engagement_score": engagement,
            "confidence_score": confidence,
            "stress_score":     stress,
            "estimated_age":    round(age_sum / age_count, 1) if age_count else None,
            "estimated_gender": max(gender_votes, key=gender_votes.get) if gender_votes else None,
        }

        client.table("facial_analysis").insert(payload).execute()
        logger.info("Facial data saved for candidate %s (%d frames)", candidate_id, len(analysis_list))
        return True

    except Exception:
        logger.error(traceback.format_exc())
        return False


#  Interview session 

def save_interview_session(candidate_id: str, session_data: dict) -> bool:
    client = _get_client()
    if client is None:
        return False
    try:
        payload = {
            "candidate_id": candidate_id,
            "session_id":   session_data.get("session_id", ""),
            "questions":    session_data.get("questions", []),
            "qa_pairs":     session_data.get("qa_pairs", []),
        }
        client.table("interview_sessions").insert(payload).execute()
        logger.info("Interview session saved for candidate %s", candidate_id)
        return True
    except Exception:
        logger.error(traceback.format_exc())
        return False


#  Final report 

def save_final_report(candidate_id: str, report: dict) -> bool:
    client = _get_client()
    if client is None:
        return False
    try:
        payload = {
            "candidate_id":         candidate_id,
            "decision":             report.get("decision", "On Hold"),
            "overall_score":        report.get("overall_score"),
            "technical_score":      report.get("technical_score"),
            "communication_score":  report.get("communication_score"),
            "confidence_score":     report.get("confidence_score"),
            "emotional_score":      report.get("emotional_score"),
            "strengths":            report.get("strengths", []),
            "improvements":         report.get("improvements", []),
            "summary":              report.get("summary", ""),
            "recommendation":       report.get("recommendation", ""),
            "facial_summary":       report.get("facial_summary", {}),
        }
        client.table("final_reports").insert(payload).execute()

        # Also update top-level candidate status + decision
        client.table("candidates").update(
            {"status": "completed", "decision": report.get("decision", "On Hold")}
        ).eq("id", candidate_id).execute()

        logger.info(
            "Final report saved for candidate %s — decision: %s",
            candidate_id,
            report.get("decision"),
        )
        return True

    except Exception:
        logger.error(traceback.format_exc())
        return False


def delete_candidate(candidate_id: str) -> bool:
    client = _get_client()
    if client is None: return False
    try:
        client.table("candidates").delete().eq("id", candidate_id).execute()
        return True
    except Exception:
        logger.error(traceback.format_exc())
        return False


def delete_meeting(meeting_id: str) -> bool:
    client = _get_client()
    if client is None: return False
    try:
        client.table("meetings").delete().eq("meeting_id", meeting_id).execute()
        return True
    except Exception:
        logger.error(traceback.format_exc())
        return False
