"""
local_test.py — Quick sanity-check that Gemini API works without Firebase.
Run: python local_test.py
"""
import os

# ── Test Gemini
print("Testing Gemini connection...")
try:
    import google.generativeai as genai
    from config import GEMINI_API_KEY
    if GEMINI_API_KEY == "YOUR_GEMINI_API_KEY_HERE":
        print("⚠️  GEMINI_API_KEY not set in config.py")
    else:
        genai.configure(api_key=GEMINI_API_KEY)
        model = genai.GenerativeModel("gemini-1.5-flash")
        res = model.generate_content("Say: Ready for interviews!")
        print(f"✅ Gemini OK: {res.text.strip()}")
except Exception as e:
    print(f"❌ Gemini error: {e}")

#  Test gTTS
print("\nTesting gTTS...")
try:
    from gtts import gTTS
    import io
    tts = gTTS("Hello, I am your AI interviewer.", lang="en")
    buf = io.BytesIO()
    tts.write_to_fp(buf)
    print(f"✅ gTTS OK — generated {buf.tell()} bytes of audio")
except Exception as e:
    print(f"❌ gTTS error: {e}")

#  Test DeepFace import
print("\nTesting DeepFace import...")
try:
    from deepface import DeepFace
    print("✅ DeepFace imported successfully")
except Exception as e:
    print(f"❌ DeepFace error: {e}")

#  Test Flask
print("\nTesting Flask import...")
try:
    from flask import Flask
    print("✅ Flask imported successfully")
except Exception as e:
    print(f"❌ Flask error: {e}")

#  Test Supabase (optional)
print("\nTesting Supabase (optional)...")
try:
    from config import SUPABASE_URL, SUPABASE_KEY
    if "YOUR-PROJECT-ID" in SUPABASE_URL or "YOUR_SUPABASE" in SUPABASE_KEY:
        print("⚠️  Supabase credentials not set in config.py — interviews will run without persistence")
    else:
        from supabase import create_client
        client = create_client(SUPABASE_URL, SUPABASE_KEY)
        print("✅ Supabase client initialised successfully")
except Exception as e:
    print(f"⚠️  Supabase: {e}")

print("\n✅ All checks complete! Run: python app.py")
