# AIcruiter — AI-Powered Smart Hiring System

![Python](https://img.shields.io/badge/Python-3.10+-blue)
![Gemini](https://img.shields.io/badge/Gemini-1.5%20Pro-purple)
![Supabase](https://img.shields.io/badge/Supabase-Postgres-green)
![DeepFace](https://img.shields.io/badge/DeepFace-Facial%20AI-green)

A fully-featured, modern AI interview system powered by **Google Gemini**, with:
- 📄 CV & Job Description upload (PDF/DOCX/TXT)
- 🧠 AI-generated interview questions tailored to the candidate
- 🎙️ AI Voice Agent (Text-to-Speech) that conducts the interview
- 📹 Candidate webcam video with real-time facial emotion analysis (DeepFace)
- 🗣️ Browser-native speech recognition → live transcript
- 📊 Automatic answer scoring via Gemini
- 🔥 All data (facial analysis, QA, decision) persisted to Supabase (Postgres)
- 📋 Comprehensive hiring report with final decision

---

## Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Configure credentials

Edit **`config.py`** (or set environment variables):

| Key | Where to get it |
|-----|----------------|
| `GEMINI_API_KEY` | [Google AI Studio](https://aistudio.google.com/app/apikey) |
| `SUPABASE_URL` | Supabase Dashboard → Project Settings → API |
| `SUPABASE_KEY` | Supabase Dashboard → Project Settings → API (anon or service_role) |

### 3. Setup Supabase
- **Database Schema**: Run the SQL found in **`supabase_schema.sql`** in your Supabase SQL Editor to create the necessary tables.
- **Storage Bucket**: Create a new **Public** bucket named **`interviews`** in your Supabase Storage dashboard. This will store the candidate's CV and JD.

### 4. Run the server

```bash
python app.py
```

Open your browser at **http://localhost:5000**

---

## Architecture

```
┌─────────────────────────────────────────────────────┐
│                    Browser (Frontend)                │
│  ┌───────────┐  ┌───────────────┐  ┌─────────────┐ │
│  │  Setup UI │  │ Interview Room│  │   Report    │ │
│  │  (Upload) │  │  (Voice+Video)│  │  Dashboard  │ │
│  └─────┬─────┘  └──────┬────────┘  └──────┬──────┘ │
└────────┼───────────────┼──────────────────┼─────────┘
         │ REST API       │ Frames/Answers   │
┌────────▼───────────────▼──────────────────▼─────────┐
│                   Flask Backend                      │
│  ┌─────────────┐  ┌──────────────┐  ┌────────────┐  │
│  │gemini_service│  │facial_analysis│ │supabase_svc│  │
│  │  • Q-gen    │  │  • DeepFace  │  │  • CRUD    │  │
│  │  • Eval     │  │  • Emotions  │  │  • Reports │  │
│  │  • Report   │  │  • Stress    │  │  • History │  │
│  │  • TTS(gTTS)│  └──────────────┘  └────────────┘  │
│  └─────────────┘                                     │
└────────────────────────────────────────────────────┘
         │                           │
    Google Gemini              Supabase (Postgres)
    (1.5 Pro / Flash)          + Storage
```

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/upload` | Upload CV + JD, generate questions |
| GET  | `/api/questions/<session_id>` | Get all questions |
| GET  | `/api/next-question/<session_id>` | Get next question + TTS audio |
| POST | `/api/submit-answer` | Submit & score an answer |
| POST | `/api/analyse-frame` | Send webcam frame for facial analysis |
| POST | `/api/end-interview` | Finalise, generate report |
| GET  | `/api/report/<candidate_id>` | Retrieve a report |
| GET  | `/api/candidates` | List all candidates |
| POST | `/api/tts` | Convert text to speech |
| GET  | `/api/health` | Health check |

## Supabase Data Structure

The system uses 4 core tables:
1. `candidates`: Stores personal info and final decision status.
2. `interview_sessions`: Stores the full Q&A pairs and scores.
3. `facial_analysis`: Stores aggregated emotion data and frame references.
4. `final_reports`: Stores the comprehensive AI evaluation.

## Environment Variables (alternative to editing config.py)

```bash
set GEMINI_API_KEY=your_key_here
set SUPABASE_URL=https://your-project.supabase.co
set SUPABASE_KEY=your-anon-or-service-role-key
```

## Browser Requirements

- Chrome / Edge (best Web Speech API support)
- Camera & Microphone permissions required
- JavaScript enabled

---
*Built with ❤️ using Google Gemini, DeepFace, Supabase & Flask*
