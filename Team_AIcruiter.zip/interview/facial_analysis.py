"""
Facial analysis service using DeepFace.

The browser periodically sends a base64-encoded JPEG frame via WebSocket /
REST. This module decodes it and runs DeepFace analysis (emotion, age, gender).
Results are accumulated in memory then persisted to Firebase at interview end.
"""

import base64
import logging
import traceback
from io import BytesIO

import numpy as np
from PIL import Image

logger = logging.getLogger(__name__)

# In-memory per-session store  {session_id: [frame_result, ...]}
_session_frames: dict[str, list] = {}


def _decode_frame(b64_data: str) -> np.ndarray | None:
    """Decode a base64 JPEG/PNG string to a numpy BGR array."""
    try:
        # Strip data-URL prefix if present  (data:image/jpeg;base64,…)
        if "," in b64_data:
            b64_data = b64_data.split(",", 1)[1]
        raw = base64.b64decode(b64_data)
        img = Image.open(BytesIO(raw)).convert("RGB")
        arr = np.array(img)          # RGB
        arr = arr[:, :, ::-1]        # → BGR for OpenCV / DeepFace
        return arr
    except Exception:
        logger.error(traceback.format_exc())
        return None


def analyse_frame(b64_frame: str, session_id: str) -> dict:
    """
    Analyse a single webcam frame.
    Returns a dict with emotion scores, dominant emotion, age, gender.
    Also appends the result to the in-memory session store.
    """
    result = {
        "session_id": session_id,
        "emotions": {},
        "dominant_emotion": "unknown",
        "age": None,
        "gender": None,
        "error": None,
    }

    frame = _decode_frame(b64_frame)
    if frame is None:
        result["error"] = "Failed to decode frame"
        return result

    try:
        from deepface import DeepFace
        from config import DEEPFACE_BACKEND

        analyses = DeepFace.analyze(
            img_path=frame,
            actions=["emotion"],
            detector_backend=DEEPFACE_BACKEND,
            enforce_detection=False,
            silent=True,
        )
        # DeepFace returns a list if multiple faces; take first face
        analysis = analyses[0] if isinstance(analyses, list) else analyses

        # Convert all emotion values to Python floats to prevent JSON numpy serialization errors
        raw_emotions = analysis.get("emotion", {})
        result["emotions"] = {k: float(v) for k, v in raw_emotions.items()}
        result["dominant_emotion"] = analysis.get("dominant_emotion", "neutral")
        result["age"] = analysis.get("age")
        raw_gender = analysis.get("dominant_gender") or analysis.get("gender")
        if isinstance(raw_gender, dict):
            result["gender"] = max(raw_gender, key=raw_gender.get)
        else:
            result["gender"] = str(raw_gender) if raw_gender else None

    except Exception as exc:
        result["error"] = str(exc)
        logger.debug("DeepFace analysis error: %s", exc)

    # Accumulate
    if session_id not in _session_frames:
        _session_frames[session_id] = []
    _session_frames[session_id].append(result)

    return result


def get_session_frames(session_id: str) -> list:
    """Return all recorded frames for a session."""
    return _session_frames.get(session_id, [])


def get_emotion_summary(session_id: str) -> dict:
    """
    Aggregate emotion data across all frames into a summary dict.
    """
    frames = get_session_frames(session_id)
    if not frames:
        return {}

    totals: dict[str, float] = {}
    valid = 0
    age_sum = 0
    age_count = 0
    gender_votes: dict[str, int] = {}

    for frame in frames:
        emotions = frame.get("emotions")
        if not emotions:
            continue
        valid += 1
        for emotion, score in emotions.items():
            totals[emotion] = totals.get(emotion, 0.0) + score
        if frame.get("age"):
            age_sum += frame["age"]
            age_count += 1
        gender = frame.get("gender")
        if gender:
            gender_votes[gender] = gender_votes.get(gender, 0) + 1

    if valid == 0:
        return {}

    avg_emotions = {k: round((v / 100) / valid, 2) for k, v in totals.items()}
    dominant = max(avg_emotions, key=avg_emotions.get) if avg_emotions else "neutral"

    return {
        "dominant_emotion": dominant,
        "avg_emotions": avg_emotions,
        "estimated_age": round(age_sum / age_count, 1) if age_count else None,
        "estimated_gender": max(gender_votes, key=gender_votes.get) if gender_votes else None,
        "frames_analysed": valid,
        "confidence_score": _calc_confidence(avg_emotions),
    }


def clear_session(session_id: str):
    _session_frames.pop(session_id, None)


#  Derived scores 

def _calc_engagement(emotions: dict) -> float:
    """Estimate engagement from emotion scores (0-100)."""
    positive = emotions.get("happy", 0) + emotions.get("surprise", 0) * 0.5
    return min(round(positive * 1.2, 1), 100)


def _calc_confidence(emotions: dict) -> float:
    """Estimate confidence (low fear/sadness = higher confidence)."""
    fear    = emotions.get("fear", 0)
    sad     = emotions.get("sad", 0)
    disgust = emotions.get("disgust", 0)
    penalty = (fear + sad + disgust) / 3
    return max(round(100 - penalty, 1), 0)


def _calc_stress(emotions: dict) -> float:
    """Estimate stress level from negative emotions."""
    fear    = emotions.get("fear", 0)
    angry   = emotions.get("angry", 0)
    disgust = emotions.get("disgust", 0)
    return min(round((fear + angry + disgust) / 3, 1), 100)
