"""
Configuration for AI Interview System
Fill in your credentials below, or set the corresponding environment variables.
"""

import os

#  Gemini AI 
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "AIzaSyB6T4g3ZnAEkOCCndIa5CR5Nh5cVCuMOEQ")
GEMINI_MODEL   = "gemini-2.5-flash"

#  Supabase 
# Find these in: Supabase Dashboard → Project Settings → API
SUPABASE_URL = os.environ.get("SUPABASE_URL", "https://qtphfnmklqajqxpensuf.supabase.co")
SUPABASE_KEY = os.environ.get("SUPABASE_KEY", "sb_publishable_7m_7CxC7xSnDdbGstqPzOg_CwojOUvQ")
SUPABASE_BUCKET = "interview"

#  App 
UPLOAD_FOLDER   = "uploads"
MAX_CONTENT_MB  = 16
SECRET_KEY      = os.environ.get("SECRET_KEY", "ai-interview-secret-2024")

#  Facial Analysis 
FACE_ANALYSIS_INTERVAL_SEC = 5       # Faster for live monitor feel
DEEPFACE_BACKEND            = "opencv"  # opencv | ssd | dlib | mtcnn | retinaface

#  Interview 
MAX_QUESTIONS        = 10
QUESTION_TIMEOUT_SEC = 90

#  Admin Panel 
ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "alpha123")  # Change this!
