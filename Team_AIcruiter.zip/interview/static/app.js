/**
 * AIcruiter — Frontend Application Logic
 * ==========================================
 * Handles:
 *  - Multi-screen navigation
 *  - File upload & setup form
 *  - Camera / microphone access
 *  - Interview flow (questions → TTS → user answers)
 *  - Web Speech API (speech recognition)
 *  - Periodic frame capture & facial analysis
 *  - Final report rendering
 */

'use strict';

const API = '';   // Same origin (Flask serves both)

// ─── Emotion color map ────────────────────────────────────────────────────────
const EMOTION_COLORS = {
    happy: '#10b981', neutral: '#94a3b8', sad: '#60a5fa',
    angry: '#ef4444', fear: '#a78bfa', disgust: '#f59e0b', surprise: '#f472b6',
};

// ─── State ────────────────────────────────────────────────────────────────────
const State = {
    sessionId: null,
    candidateId: null,
    candidate: {},
    questions: [],
    currentIndex: 0,
    qaHistory: [],
    cameraStream: null,
    cameraEnabled: false,
    micEnabled: false,
    transcript: '',
    recognition: null,
    timerInterval: null,
    elapsedSeconds: 0,
    faceInterval: null,
    currentAudio: null,
    emotionHistory: [],
    isSpeaking: false,
    questionAudio: null,
    speechVoice: null,
    meetingId: null, // Track if joined via link
};

// ─── Initialisation ──────────────────────────────────────────────────────────

window.addEventListener('DOMContentLoaded', async () => {
    // Check for meetingId in URL search params (direct link)
    const params = new URLSearchParams(window.location.search);
    let mid = params.get('meetingId');

    // Also check hash (SPA style)
    if (!mid && window.location.hash.includes('meetingId=')) {
        mid = window.location.hash.split('meetingId=')[1];
    }

    if (mid) {
        joinMeeting(mid);
    }
});

function syncMeetingIdInUrl(mid) {
    if (!mid || !window.history || typeof window.history.replaceState !== 'function') return;
    const params = new URLSearchParams(window.location.search);
    params.set('meetingId', mid);
    const nextUrl = `${window.location.pathname}?${params.toString()}`;
    window.history.replaceState({}, '', nextUrl);
}

async function joinMeeting(mid) {
    const normalizedMid = String(mid || '').trim().replace(/\s+/g, '').toUpperCase();
    if (!normalizedMid) {
        _showLandingError('Meeting link invalid or expired.');
        return;
    }
    State.meetingId = normalizedMid;
    try {
        const res = await fetch(`${API}/api/meeting/${encodeURIComponent(normalizedMid)}`);
        const data = await res.json();

        if (res.ok) {
            syncMeetingIdInUrl(normalizedMid);
            const mtgTitle = document.getElementById('mtg-title');
            if (mtgTitle) mtgTitle.textContent = "Interview for: " + (data.job_title || "Position");
            showScreen('screen-setup'); // AUTO-NAVIGATE
        } else {
            _showLandingError(data.error || 'Meeting link invalid or expired.');
        }
    } catch (e) {
        console.error('Failed to fetch meeting details', e);
        _showLandingError('Connection error. Please try again.');
    }
}

async function startMeetingSetup() {
    const midInput = document.getElementById('inp-meeting-id');
    const mid = (midInput?.value || '').trim().replace(/\s+/g, '').toUpperCase();
    if (!mid) return alert('Please enter a valid Meeting ID');

    if (midInput) {
        midInput.value = mid;
    }

    const btn = document.getElementById('btn-join-meeting');
    const text = document.getElementById('btn-join-text');
    const spin = document.getElementById('join-spinner');
    const err = document.getElementById('landing-error');

    if (err) err.classList.add('hidden');
    btn.disabled = true;
    text.textContent = 'Verifying...';
    spin.classList.remove('hidden');

    try {
        const res = await fetch(`${API}/api/meeting/${encodeURIComponent(mid)}`);
        const data = await res.json();

        if (!res.ok) throw new Error(data.error || 'Meeting not found');

        State.meetingId = mid;
        syncMeetingIdInUrl(mid);
        const mtgTitle = document.getElementById('mtg-title');
        if (mtgTitle) mtgTitle.textContent = "Interview for: " + data.job_title;

        showScreen('screen-setup');
    } catch (e) {
        _showLandingError(e.message);
    } finally {
        btn.disabled = false;
        text.textContent = 'Join Secure Session';
        spin.classList.add('hidden');
    }
}

function _showLandingError(msg) {
    const landingError = document.getElementById('landing-error');
    if (landingError) {
        landingError.textContent = msg;
        landingError.classList.remove('hidden');
        return;
    }

    const setupError = document.getElementById('setup-error');
    if (setupError) {
        setupError.textContent = msg;
        setupError.classList.remove('hidden');
        showScreen('screen-setup');
        return;
    }

    alert(msg);
}

function showToast(text) {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        document.body.appendChild(container);
    }
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = text;
    container.appendChild(toast);
    setTimeout(() => {
        toast.classList.add('hide');
        setTimeout(() => toast.remove(), 500);
    }, 4000);
}

// ─── Screen management ────────────────────────────────────────────────────────

function showScreen(id) {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    const target = document.getElementById(id);
    if (target) target.classList.add('active');
}

// ─── Camera ───────────────────────────────────────────────────────────────────

async function toggleCamera() {
    if (State.cameraEnabled) {
        stopCamera();
        return;
    }
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        State.cameraStream = stream;
        State.cameraEnabled = true;
        State.micEnabled = true;

        const preview = document.getElementById('cam-preview');
        if (preview) {
            preview.srcObject = stream;
            document.getElementById('cam-overlay')?.classList.add('hidden');
        }

        const userVid = document.getElementById('user-video');
        if (userVid) userVid.srcObject = stream;

        const btn = document.getElementById('cam-btn-text');
        if (btn) btn.textContent = '📷 Disable Camera';
    } catch (err) {
        console.error('Camera error:', err);
        showToast('Could not access camera/microphone. Please allow permissions.');
    }
}

function stopCamera() {
    if (State.cameraStream) {
        State.cameraStream.getTracks().forEach(t => t.stop());
        State.cameraStream = null;
    }
    State.cameraEnabled = false;
    State.micEnabled = false;
    const preview = document.getElementById('cam-preview');
    if (preview) preview.srcObject = null;
    const btnText = document.getElementById('cam-btn-text');
    if (btnText) btnText.textContent = '📷 Enable Camera';
    _setDot('cam-status', '');
    _setDot('mic-status', '');
}

function _setDot(statusId, cls) {
    const el = document.getElementById(statusId);
    if (!el) return;
    const dot = el.querySelector('.dot');
    if (dot) { dot.className = 'dot'; if (cls) dot.classList.add(cls); }
}

// ─── File upload helpers ──────────────────────────────────────────────────────

function handleFileSelect(input, zoneId, nameId) {
    const file = input.files[0];
    if (!file) return;
    const zone = document.getElementById(zoneId);
    const name = document.getElementById(nameId);
    if (zone) zone.classList.add('has-file');
    if (name) {
        name.textContent = `✓ ${file.name}`;
        name.style.color = '#10b981';
    }
}

// ─── Drag-and-drop ────────────────────────────────────────────────────────────

['cv-zone', 'jd-zone'].forEach(zoneId => {
    const zone = document.getElementById(zoneId);
    if (!zone) return;
    zone.addEventListener('dragover', e => { e.preventDefault(); zone.style.borderColor = '#7c3aed'; });
    zone.addEventListener('dragleave', () => { zone.style.borderColor = ''; });
    zone.addEventListener('drop', e => {
        e.preventDefault();
        zone.style.borderColor = '';
        const file = e.dataTransfer.files[0];
        if (!file) return;
        const inputId = zoneId === 'cv-zone' ? 'inp-cv' : 'inp-jd';
        const nameId = zoneId === 'cv-zone' ? 'cv-name' : 'jd-name';
        const input = document.getElementById(inputId);
        if (input) {
            // Assign via DataTransfer
            const dt = new DataTransfer();
            dt.items.add(file);
            input.files = dt.files;
            handleFileSelect(input, zoneId, nameId);
        }
    });
});

// ─── Setup form submission ────────────────────────────────────────────────────

async function handleSetupSubmit(e) {
    if (e) e.preventDefault();

    const btn = document.getElementById('btn-submit-setup');
    const text = document.getElementById('btn-submit-text');
    const spin = document.getElementById('setup-spinner');
    const err = document.getElementById('setup-error');

    // Reset UI
    err.classList.add('hidden');
    err.textContent = '';

    // Validate camera
    if (!State.cameraEnabled) {
        _showSetupError('Please enable your camera before starting.');
        return;
    }

    const name = document.getElementById('inp-name').value.trim();
    const email = document.getElementById('inp-email').value.trim();

    if (!name || !email) {
        _showSetupError('Please enter your full name and email address.');
        return;
    }

    if (!State.meetingId) {
        _showSetupError('Invalid session. Please return home and enter a Meeting ID.');
        return;
    }

    // Prepare data
    const formData = new FormData();
    formData.append('name', name);
    formData.append('email', email);
    formData.append('meeting_id', State.meetingId);

    // Visual feedback
    btn.disabled = true;
    text.textContent = 'Initiating Session…';
    spin.classList.remove('hidden');

    showScreen('screen-loading');

    try {
        const res = await fetch(`${API}/api/upload`, { method: 'POST', body: formData });
        const data = await res.json();

        if (!res.ok) {
            throw new Error(data.error || 'Server error occured.');
        }

        State.sessionId = data.session_id;
        State.candidateId = data.candidate_id;
        State.candidate = data.candidate;
        State.questions = data.questions || [];

        if (State.questions.length === 0) {
            throw new Error("No questions were generated for this role.");
        }

        await _delay(1500);
        launchInterview();

    } catch (ex) {
        console.error("Submission failed:", ex);
        showScreen('screen-setup');
        _showSetupError(ex.message || 'An unexpected error occurred.');
        btn.disabled = false;
        text.textContent = 'Initiate Interview';
        spin.classList.add('hidden');
    }
}

function _showSetupError(msg) {
    const el = document.getElementById('setup-error');
    if (el) { el.textContent = msg; el.classList.remove('hidden'); }
}

// ─── Loading animation ────────────────────────────────────────────────────────

function startLoadingAnimation() {
    const steps = ['step-parse', 'step-analyze', 'step-generate', 'step-ready'];
    const messages = [
        'Parsing your CV and job description…',
        'Analysing your skills and requirements…',
        'Generating personalised questions with Gemini…',
        'Preparing your AI interviewer…',
    ];
    let i = 0;
    const advance = () => {
        if (i > 0) {
            const prev = document.getElementById(steps[i - 1]);
            if (prev) { prev.classList.remove('active'); prev.classList.add('done'); }
        }
        if (i < steps.length) {
            const cur = document.getElementById(steps[i]);
            if (cur) cur.classList.add('active');
            const msg = document.getElementById('loading-message');
            if (msg) msg.textContent = messages[i];
            i++;
            setTimeout(advance, 1200);
        }
    };
    advance();
}

// ─── Launch interview ─────────────────────────────────────────────────────────

async function launchInterview() {
    showScreen('screen-interview');

    // Pipe camera to interview video
    const vid = document.getElementById('user-video');
    if (vid && State.cameraStream) vid.srcObject = State.cameraStream;

    document.getElementById('user-name-tag').textContent = State.candidate.name || 'Candidate';

    // Start timer
    startTimer();

    // Start face analysis loop (every 5 seconds)
    startFaceAnalysis();

    // Start speech recognition
    startSpeechRecognition();

    // Ask first question
    await askNextQuestion();
}

// ─── Timer ────────────────────────────────────────────────────────────────────

function startTimer() {
    State.elapsedSeconds = 0;
    State.timerInterval = setInterval(() => {
        State.elapsedSeconds++;
        const m = String(Math.floor(State.elapsedSeconds / 60)).padStart(2, '0');
        const s = String(State.elapsedSeconds % 60).padStart(2, '0');
        const el = document.getElementById('interview-timer');
        if (el) el.textContent = `${m}:${s}`;
    }, 1000);
}

// ─── Face analysis ────────────────────────────────────────────────────────────

function startFaceAnalysis() {
    State.faceInterval = setInterval(captureAndAnalyseFace, 5000);
}

async function captureAndAnalyseFace() {
    if (!State.sessionId || !State.cameraStream) return;
    const vid = document.getElementById('user-video');
    if (!vid || vid.readyState < 2) return;

    try {
        const canvas = document.createElement('canvas');
        canvas.width = 320;
        canvas.height = 240;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(vid, 0, 0, canvas.width, canvas.height);
        const b64 = canvas.toDataURL('image/jpeg', 0.7);

        const res = await fetch(`${API}/api/analyse-frame`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ session_id: State.sessionId, frame: b64 }),
        });
        const data = await res.json();
        if (data.emotions) {
            updateEmotionHUD(data);
            State.emotionHistory.push({ emotion: data.dominant_emotion, ts: State.elapsedSeconds });
            updateEmotionTimeline();
        }
    } catch (err) {
        // Silently ignore face analysis errors during interview
    }
}


function updateEmotionHUD(data) {
    const valEl = document.getElementById('emotion-value');
    const barsEl = document.getElementById('emotion-bars');
    if (!valEl || !barsEl) return;

    valEl.textContent = data.dominant_emotion || '—';
    valEl.style.color = EMOTION_COLORS[data.dominant_emotion] || '#fff';

    const emotions = data.emotions || {};
    const max = Math.max(...Object.values(emotions), 1);
    barsEl.innerHTML = '';

    Object.entries(emotions).forEach(([name, score]) => {
        const pct = Math.round((score / max) * 100);
        const color = EMOTION_COLORS[name] || '#7c3aed';
        barsEl.innerHTML += `
      <div class="e-bar-wrap" title="${name}: ${score.toFixed(1)}%">
        <div class="e-bar" style="height:${pct}%;background:${color}"></div>
        <span class="e-bar-label">${name.slice(0, 3)}</span>
      </div>`;
    });
}

function updateEmotionTimeline() {
    const container = document.getElementById('eh-bars');
    if (!container) return;
    // Keep only last 30 entries
    const recent = State.emotionHistory.slice(-30);
    container.innerHTML = recent.map(e => {
        const color = EMOTION_COLORS[e.emotion] || '#7c3aed';
        return `<div class="eh-segment" style="background:${color};height:${Math.random() * 60 + 20}%"
              data-tooltip="${e.emotion} @ ${e.ts}s"></div>`;
    }).join('');
}

// ─── Ask next question ────────────────────────────────────────────────────────

async function askNextQuestion() {
    if (!State.sessionId) return;

    setAIStatus('Thinking…');
    setAISpeaking(false);

    try {
        const res = await fetch(`${API}/api/next-question/${State.sessionId}`);
        const data = await res.json();

        if (data.done) {
            // All questions answered
            await _delay(500);
            endInterview();
            return;
        }

        State.currentIndex = data.index;
        State.questionAudio = data.audio;

        // Update UI
        document.getElementById('q-counter').textContent = `Question ${data.index + 1} / ${State.questions.length || data.total}`;
        document.getElementById('q-text').textContent = data.question.question;
        document.getElementById('q-category').textContent = data.question.category || '';
        document.getElementById('text-answer').value = '';
        State.transcript = '';
        _updateTranscript('');

        // Play AI voice
        if (data.audio) {
            await playTTSAudio(data.audio, data.question.question);
        } else {
            setAIStatus('Listening to your answer…');
        }

    } catch (err) {
        console.error('Next Q error:', err);
        setAIStatus('Ready');
    }
}

async function replayQuestion() {
    if (State.questionAudio) {
        await playTTSAudio(State.questionAudio, document.getElementById('q-text').textContent);
    }
}

// ─── TTS playback ─────────────────────────────────────────────────────────────

async function playTTSAudio(b64mp3, questionText) {
    return new Promise(resolve => {
        // Stop any previous audio
        if (State.currentAudio) {
            State.currentAudio.pause();
            State.currentAudio = null;
        }

        if (!b64mp3) {
            console.warn('TTS audio missing, falling back to browser speech synthesis.');
            const msg = new SpeechSynthesisUtterance(questionText);
            State.speechVoice = msg; // Hold reference to prevent GC on some browsers

            msg.onend = () => {
                setAISpeaking(false);
                setAIStatus('Listening to your answer…');
                State.speechVoice = null;
                resolve();
            };
            msg.onerror = (e) => {
                console.error('Speech synthesis error:', e);
                State.speechVoice = null;
                resolve();
            };

            setAIStatus('Speaking…');
            setAISpeaking(true);
            window.speechSynthesis.speak(msg);

            // Safety timeout: resolve if onend never fires (e.g. browser blocks it)
            setTimeout(() => {
                if (State.speechVoice === msg) {
                    State.speechVoice = null;
                    resolve();
                }
            }, 10000);
            return;
        }

        const audio = new Audio(`data:audio/mp3;base64,${b64mp3}`);
        State.currentAudio = audio;

        setAIStatus('Speaking…');
        setAISpeaking(true);

        audio.onended = () => {
            setAISpeaking(false);
            setAIStatus('Listening to your answer…');
            State.currentAudio = null;
            resolve();
        };
        audio.onerror = (e) => {
            console.error('Audio playback error:', e);
            setAISpeaking(false);
            setAIStatus('Listening to your answer…');
            resolve();
        };

        audio.play().catch(() => resolve());
    });
}

function setAISpeaking(on) {
    State.isSpeaking = on;
    const indicator = document.getElementById('ai-speaking');
    const mouth = document.getElementById('avatar-mouth');
    if (indicator) indicator.classList.toggle('active', on);
    if (mouth) mouth.classList.toggle('speaking', on);
}

function setAIStatus(text) {
    const el = document.getElementById('ai-status-text');
    if (el) el.textContent = text;
}

// ─── Microphone toggle ────────────────────────────────────────────────────────

function toggleMic() {
    const btn = document.getElementById('btn-mic');
    const icon = document.getElementById('mic-icon');
    if (!State.recognition) {
        showToast('Speech recognition not available in this browser. Type your answer instead.');
        return;
    }
    if (State.micEnabled) {
        State.recognition.stop();
        State.micEnabled = false;
        if (btn) btn.classList.remove('active');
        if (icon) icon.textContent = '🎙️';
    } else {
        State.recognition.start();
        State.micEnabled = true;
        if (btn) btn.classList.add('active');
        if (icon) icon.textContent = '🔴';
    }
}

// ─── Speech recognition ───────────────────────────────────────────────────────

function startSpeechRecognition() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    const rec = new SpeechRecognition();
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = 'en-US';

    rec.onresult = event => {
        let interim = ''; let final = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
            const t = event.results[i][0].transcript;
            if (event.results[i].isFinal) final += t + ' ';
            else interim += t;
        }
        if (final) State.transcript += final;
        _updateTranscript(State.transcript + interim);
        // Mirror to textarea
        const area = document.getElementById('text-answer');
        if (area) area.value = State.transcript + interim;
    };

    rec.onerror = err => { console.warn('SR error:', err); };

    rec.onend = () => {
        // Auto-restart if still "listening"
        if (State.micEnabled) setTimeout(() => { try { rec.start(); } catch (e) { } }, 200);
    };

    State.recognition = rec;

    // Auto-start mic
    try {
        rec.start();
        State.micEnabled = true;
        const btn = document.getElementById('btn-mic');
        const icon = document.getElementById('mic-icon');
        if (btn) btn.classList.add('active');
        if (icon) icon.textContent = '🔴';
    } catch (e) { /* might fail if already started */ }
}

function _updateTranscript(text) {
    const el = document.getElementById('transcript-content');
    if (!el) return;
    if (!text.trim()) {
        el.innerHTML = '<span class="transcript-placeholder">Start speaking — your words appear here…</span>';
    } else {
        el.textContent = text;
        el.scrollTop = el.scrollHeight;
    }
}

function clearTranscript() {
    State.transcript = '';
    _updateTranscript('');
    document.getElementById('text-answer').value = '';
}

// ─── Submit answer ────────────────────────────────────────────────────────────

async function submitCurrentAnswer() {
    const btn = document.getElementById('btn-answer');
    if (!btn) return;
    btn.textContent = '⏳ Submitting…';

    // Get answer from textarea (either typed or speech-to-text)
    const answer = document.getElementById('text-answer').value.trim()
        || State.transcript.trim()
        || '(No answer provided)';

    // Stop mic temporarily
    if (State.recognition) { try { State.recognition.stop(); } catch (e) { } }
    State.micEnabled = false;

    try {
        const res = await fetch(`${API}/api/submit-answer`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                session_id: State.sessionId,
                question_index: State.currentIndex,
                answer,
            }),
        });
        const data = await res.json();

        // Record locally
        State.qaHistory.push({
            question: State.questions[State.currentIndex]?.question || '',
            answer,
            score: data.score || {},
        });

        // ── Handle Dynamic Follow-up
        if (data.follow_up) {
            // Display follow-up in the UI as the current question
            document.getElementById('q-text').textContent = data.follow_up;
            document.getElementById('q-category').textContent = 'clarification';
            document.getElementById('text-answer').value = '';
            State.transcript = '';
            _updateTranscript('');

            // Play follow-up audio
            await playTTSAudio(data.follow_up_audio, data.follow_up);

            // Re-enable button but DO NOT call askNextQuestion yet
            btn.disabled = false;
            btn.textContent = '✓ Submit Answer';
            if (State.recognition) { try { State.recognition.start(); State.micEnabled = true; } catch (e) { } }
            return;
        }

        // ── Normal progress: Play acknowledgement audio
        if (data.ack_audio) {
            await playTTSAudio(data.ack_audio, data.ack_text || 'Thank you…');
        }

        // Ask next question
        btn.disabled = false;
        btn.textContent = '✓ Submit Answer';
        State.transcript = '';
        _updateTranscript('');

        // Restart mic
        if (State.recognition) {
            try { State.recognition.start(); State.micEnabled = true; } catch (e) { }
        }

        await askNextQuestion();

    } catch (err) {
        console.error('Submit error:', err);
        showToast('Error submitting answer. Check your connection.');
        btn.disabled = false;
        btn.textContent = '✓ Submit Answer';
    }
}

// ─── End interview ────────────────────────────────────────────────────────────

function confirmEndInterview() {
    document.getElementById('end-modal').classList.remove('hidden');
}

function closeModal() {
    document.getElementById('end-modal').classList.add('hidden');
}

async function endInterview() {
    closeModal();
    // Stop everything immediately
    clearInterval(State.timerInterval);
    clearInterval(State.faceInterval);
    if (State.recognition) { try { State.recognition.stop(); } catch (e) { } }
    if (State.currentAudio) { try { State.currentAudio.pause(); } catch (e) { } }

    // Notify server asynchronously
    try {
        fetch(`${API}/api/end-interview`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ session_id: State.sessionId }),
        }).catch(e => console.warn('end-interview notify failed:', e));
    } catch (e) { console.warn('end-interview exception:', e); }

    // Persist candidate name for final page
    const candidateName = State.candidate?.name || 'Candidate';
    try { window.sessionStorage.setItem(INTERVIEW_COMPLETE_NAME_KEY, candidateName); } catch (e) { }

    // Redirect to complete page for immediate feedback
    if (State.meetingId) {
        window.location.href = `/?meetingId=${encodeURIComponent(State.meetingId)}/interview_complete`;
        return;
    }

    // Fallback: render local report
    renderReport({ candidate: State.candidate });
    showScreen('screen-report');
}

function animateReportProgress() {
    let progress = 0;
    const messages = [
        'Analysing your answers…',
        'Processing facial expression data…',
        'Consulting Gemini AI…',
        'Generating comprehensive report…',
        'Finalising decision…',
    ];
    let msgIdx = 0;
    const fill = document.getElementById('report-progress');
    const msg = document.getElementById('report-gen-msg');
    const iv = setInterval(() => {
        progress = Math.min(progress + Math.random() * 12, 95);
        if (fill) fill.style.width = progress + '%';
        if (Math.random() > 0.7 && msgIdx < messages.length - 1) {
            msgIdx++;
            if (msg) msg.textContent = messages[msgIdx];
        }
        if (progress >= 95) clearInterval(iv);
    }, 400);
}

// ─── Render report ────────────────────────────────────────────────────────────

function renderReport(report) {
    if (!report) return;
    const container = document.getElementById('report-container');
    if (!container) return;

    const candidate = report.candidate || State.candidate;
    const decision = report.decision || 'On Hold';
    const verdictCls = decision === 'Selected' ? 'selected'
        : decision === 'Not Selected' ? 'rejected'
            : 'onhold';
    const verdictIcon = decision === 'Selected' ? '✅'
        : decision === 'Not Selected' ? '❌'
            : '⏸️';

    const fs = report.facial_summary || {};

    // Scores
    const scores = [
        { label: 'Overall', val: report.overall_score || 0 },
        { label: 'Technical', val: report.technical_score || 0 },
        { label: 'Communication', val: report.communication_score || 0 },
        { label: 'Confidence', val: report.confidence_score || 0 },
        { label: 'Emotional', val: report.emotional_score || 0 },
    ];

    const strengths = report.strengths || [];
    const improvements = report.improvements || [];

    // QA section
    const qaCols = State.qaHistory.map((qa, i) => {
        const sc = qa.score || {};
        return `
    <div class="qa-item">
      <div class="qa-q">Q${i + 1}: ${qa.question}</div>
      <div class="qa-a">${qa.answer || '(no answer)'}</div>
      <div class="qa-score">
        <span class="score-chip">Overall: ${sc.overall_score ?? '—'}/10</span>
        <span class="score-chip">Relevance: ${sc.relevance ?? '—'}/10</span>
        <span class="score-chip">Depth: ${sc.depth ?? '—'}/10</span>
        <span class="score-chip">Confidence: ${sc.confidence ?? '—'}/10</span>
      </div>
    </div>`;
    }).join('');

    // Facial stats
    const avgEm = fs.avg_emotions || {};
    const emotionStatHtml = [
        { label: 'Dominant Emotion', val: (fs.dominant_emotion || '—').toUpperCase(), color: EMOTION_COLORS[fs.dominant_emotion] || '#94a3b8' },
        { label: 'Engagement Score', val: `${fs.engagement_score ?? '—'}%`, color: '#10b981' },
        { label: 'Confidence Score', val: `${fs.confidence_score ?? '—'}%`, color: '#a78bfa' },
        { label: 'Stress Level', val: `${fs.stress_score ?? '—'}%`, color: '#ef4444' },
        { label: 'Est. Age', val: fs.estimated_age ?? '—', color: '#94a3b8' },
        { label: 'Est. Gender', val: fs.estimated_gender ?? '—', color: '#94a3b8' },
    ].map(s => `
    <div class="emotion-stat">
      <div class="emotion-stat-val" style="color:${s.color}">${s.val}</div>
      <div class="emotion-stat-label">${s.label}</div>
    </div>`).join('');

    container.innerHTML = `
    <!-- Header -->
    <div style="text-align: center; padding: 60px 20px;">
      <div style="font-size: 4rem; margin-bottom: 20px;">✅</div>
      <h2 style="font-size: 2.5rem; color: var(--text-main); margin-bottom: 15px;">Interview Complete</h2>
      <p style="font-size: 1.2rem; color: var(--text-muted); max-width: 600px; margin: 0 auto; line-height: 1.6;">
        Thank you for your time, <strong>${candidate.name || 'Candidate'}</strong>.<br> 
        Your responses and interview data have been submitted successfully. Our team will review your application and get back to you shortly.
      </p>
    </div>

    <!--Actions -->
        <div class="report-actions" style="justify-content: center; margin-top: 40px;">
            <button class="btn-primary" onclick="window.location.reload()">
                Return to Home
            </button>
        </div>
    `;

    // Animate score bars after render
    setTimeout(() => {
        document.querySelectorAll('.score-bar-fill').forEach(bar => {
            const w = bar.style.width;
            bar.style.width = '0%';
            setTimeout(() => { bar.style.width = w; }, 100);
        });
    }, 100);
}

// ─── Reset ────────────────────────────────────────────────────────────────────

function resetState() {
    Object.assign(State, {
        sessionId: null, candidateId: null, candidate: {},
        questions: [], currentIndex: 0, qaHistory: [],
        cameraStream: null, cameraEnabled: false, micEnabled: false,
        transcript: '', recognition: null,
        timerInterval: null, elapsedSeconds: 0,
        faceInterval: null, currentAudio: null, emotionHistory: [],
        isSpeaking: false, questionAudio: null,
    });
}

// ─── Toast ────────────────────────────────────────────────────────────────────

function showToast(msg, duration = 4000) {
    const t = document.createElement('div');
    t.textContent = msg;
    Object.assign(t.style, {
        position: 'fixed', bottom: '24px', left: '50%', transform: 'translateX(-50%)',
        background: '#1e1b4b', border: '1px solid rgba(124,58,237,0.4)',
        color: '#e2e8f0', padding: '12px 24px', borderRadius: '12px',
        fontSize: '0.9rem', zIndex: '9999',
        boxShadow: '0 8px 32px rgba(0,0,0,0.5)',
        animation: 'fadeSlideIn 0.3s ease',
    });
    document.body.appendChild(t);
    setTimeout(() => t.remove(), duration);
}

// ─── Utility ──────────────────────────────────────────────────────────────────

function _delay(ms) { return new Promise(r => setTimeout(r, ms)); }

// (EMOTION_COLORS defined at top of file)
