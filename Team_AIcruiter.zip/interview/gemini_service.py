"""
Gemini AI service.

Responsibilities
────────────────
1. Parse CV / JD text (from uploaded files)
2. Generate tailored interview questions
3. Evaluate candidate answers
4. Generate the final selection report (incorporating facial-emotion data)
5. Produce TTS audio for AI agent voice (using gTTS / Google Cloud TTS)
"""

import io
import os
import json
import logging
import base64
import traceback

import google.generativeai as genai
from config import GEMINI_API_KEY, GEMINI_MODEL, MAX_QUESTIONS

logger = logging.getLogger(__name__)

# Initialise once
genai.configure(api_key=GEMINI_API_KEY)

# Relax safety filters for interview context (prevents false positives)
_safety_settings = [
    {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"},
]

_model = genai.GenerativeModel(
    model_name=GEMINI_MODEL,
    safety_settings=_safety_settings
)

import time
import re

def _extract_json(text: str) -> str:
    """Robustly extract JSON from Markdown wrap or raw text."""
    match = re.search(r'```(?:json)?\s*(.*?)\s*```', text, re.DOTALL)
    if match:
        return match.group(1).strip()
    return text.strip()

def _safe_generate(prompt: str, retries: int = 3, delay: int = 2, generation_config=None):
    """Call generate_content with a simple retry loop for 429 errors."""
    for attempt in range(retries):
        try:
            return _model.generate_content(prompt, generation_config=generation_config)
        except Exception as e:
            if "429" in str(e) and attempt < retries - 1:
                wait_time = delay * (2 ** attempt)
                logger.warning("Gemini 429 limit hit. Retrying in %ds...", wait_time)
                time.sleep(wait_time)
                continue
            raise e
    return None


#  Text extraction helpers 

def extract_text_from_file(filepath: str) -> str:
    """Extract plain text from PDF or DOCX files."""
    ext = os.path.splitext(filepath)[1].lower()
    try:
        if ext == ".pdf":
            import PyPDF2
            text = []
            with open(filepath, "rb") as f:
                reader = PyPDF2.PdfReader(f)
                for page in reader.pages:
                    t = page.extract_text()
                    if t:
                        text.append(t)
            return "\n".join(text)
        elif ext in (".docx", ".doc"):
            from docx import Document
            doc = Document(filepath)
            return "\n".join([p.text for p in doc.paragraphs if p.text.strip()])
        elif ext == ".txt":
            with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                return f.read()
        else:
            logger.warning("Unsupported file type: %s", ext)
            return ""
    except Exception:
        logger.error(traceback.format_exc())
        return ""


#  Question generation 

def generate_interview_questions(cv_text: str, jd_text: str, interview_types: list = None) -> list[dict]:
    """
    Return a list of question dicts:
        [{"id": 1, "question": "...", "category": "technical|behavioral|situational"}]
    """
    types_str = ", ".join(interview_types) if interview_types else "TECHNICAL, EXPERIENCE"
    
    prompt = f"""
You are an expert HR interviewer and technical recruiter.

Your task is to conduct a professional, deep-dive interview. Create exactly {MAX_QUESTIONS} questions that strictly map the Candidate's CV to the Job Description (JD). 

Specfic Interview Focus Areas Requested: {types_str}

Focus on:
1. Identifying gaps between their experience and the JD requirements.
2. Asking for specific examples from their listed projects/experience that prove they can handle the JD's responsibilities.
3. Technical deep-dives into tools/technologies mentioned in both the CV and JD (if TECHNICAL is selected).
4. Leadership and management style (if LEADERSHIP is selected).
5. Deep verification of past roles and accomplishments (if EXPERIENCE is selected).
6. Situational questions that test their advertised seniority level.

Return your response as a JSON array ONLY — no markdown, no explanation — with this structure:
[
  {{"id": 1, "question": "...", "category": "technical|behavioral|situational"}},
  ...
]

=== CANDIDATE CV ===
{cv_text[:5000]}

=== JOB DESCRIPTION ===
{jd_text[:3000]}
"""
    try:
        logger.info(f"CV length: {len(cv_text)} chars, JD length: {len(jd_text)} chars")
        if len(cv_text.strip()) < 10:
            raise ValueError("The uploaded CV does not contain enough readable text (could it be an image?). Please upload a text-based PDF/Word document.")
        if len(jd_text.strip()) < 10:
            raise ValueError("The uploaded Job Description is missing or unreadable.")
            
        response = _safe_generate(
            prompt,
            generation_config=genai.types.GenerationConfig(response_mime_type="application/json")
        )
        raw = response.text.strip()
        parsed_json_str = _extract_json(raw)
        
        try:
            questions = json.loads(parsed_json_str)
            logger.info("Generated %d questions", len(questions))
            return questions
        except json.JSONDecodeError as e:
            logger.error("JSON parse failed. Raw response: %s", raw)
            raise e
            
    except Exception as e:
        logger.error("Generation failed: %s\n%s", e, traceback.format_exc())
        raise ValueError("Failed to generate custom AI questions from your documents. Please ensure your CV and JD contain readable text and are not just images.")


#  Answer evaluation 

def evaluate_answer(question: str, answer: str, cv_text: str, jd_text: str) -> dict:
    """Score a single answer 0-10 and return brief feedback."""
    prompt = f"""
You are a senior interviewer evaluating a candidate's answer.

Question: {question}
Candidate's Answer: {answer}

Context (brief):
CV summary: {cv_text[:800]}
Job role: {jd_text[:500]}

Evaluate the answer on:
- Relevance (0-10)
- Depth & clarity (0-10)
- Confidence (inferred from text, 0-10)

Return JSON ONLY:
{{"overall_score": <0-10>, "relevance": <0-10>, "depth": <0-10>, "confidence": <0-10>, "feedback": "<one sentence>"}}
"""
    try:
        response = _safe_generate(
            prompt,
            generation_config=genai.types.GenerationConfig(response_mime_type="application/json")
        )
        raw = response.text.strip()
        parsed_json_str = _extract_json(raw)
        
        try:
            return json.loads(parsed_json_str)
        except json.JSONDecodeError as e:
            logger.error("JSON parse failed. Raw response: %s", raw)
            raise e
    except Exception as e:
        logger.error("Evaluation failed: %s\n%s", e, traceback.format_exc())
        return {"overall_score": 5, "relevance": 5, "depth": 5, "confidence": 5, "feedback": "Answer received."}


#  Final decision report 

def generate_final_report(
    candidate_info: dict,
    jd_text: str,
    qa_pairs: list[dict],
    facial_summary: dict,
) -> dict:
    """
    Produce a structured final report and hiring decision.

    Returns:
        {
          "decision": "Selected" | "Not Selected" | "On Hold",
          "overall_score": 0-100,
          "technical_score": 0-100,
          "communication_score": 0-100,
          "confidence_score": 0-100,
          "emotional_score": 0-100,
          "strengths": [...],
          "improvements": [...],
          "summary": "...",
          "recommendation": "..."
        }
    """
    qa_text = "\n".join(
        [f"Q{i+1}: {qa['question']}\nA: {qa.get('answer','(no answer)')}\nScore: {qa.get('score', {}).get('overall_score', 'N/A')}/10"
         for i, qa in enumerate(qa_pairs)]
    )
    emotion_text = json.dumps(facial_summary, indent=2) if facial_summary else "Not available"

    prompt = f"""
You are a senior HR director making a final hiring decision.

=== CANDIDATE INFO ===
Name: {candidate_info.get('name', 'Unknown')}
Email: {candidate_info.get('email', '')}
Applied for: {candidate_info.get('job_title', '')}

=== JOB DESCRIPTION ===
{jd_text[:1500]}

=== INTERVIEW Q&A WITH SCORES ===
{qa_text}

=== FACIAL EMOTION ANALYSIS DURING INTERVIEW ===
{emotion_text}

Based on ALL of the above, provide a comprehensive hiring assessment.
Return ONLY valid JSON (no markdown, no extra text):
{{
  "decision": "Selected" | "Not Selected" | "On Hold",
  "overall_score": <0-100>,
  "technical_score": <0-100>,
  "communication_score": <0-100>,
  "confidence_score": <0-100>,
  "emotional_score": <0-100>,
  "strengths": ["...", "..."],
  "improvements": ["...", "..."],
  "summary": "<3-4 sentence executive summary>",
  "recommendation": "<actionable next step>"
}}
"""
    try:
        import google.generativeai as genai
        response = _safe_generate(
            prompt,
            generation_config=genai.types.GenerationConfig(response_mime_type="application/json")
        )
        raw = response.text.strip()
        parsed_json_str = _extract_json(raw)
        report = json.loads(parsed_json_str)
        logger.info("Final report generated. Decision: %s", report.get("decision"))
        return report
    except Exception as e:
        logger.error("Failed to generate final report: %s\n%s", e, traceback.format_exc())
        return {
            "decision": "On Hold",
            "overall_score": 50,
            "technical_score": 50,
            "communication_score": 50,
            "confidence_score": 50,
            "emotional_score": 50,
            "strengths": ["Interview completed"],
            "improvements": ["Further evaluation needed"],
            "summary": "The interview was completed. Manual review recommended.",
            "recommendation": "Schedule a follow-up interview.",
        }


#  Text-to-Speech 

def text_to_speech_base64(text: str, lang: str = "en") -> str:
    """
    Convert text to speech using gTTS and return base64-encoded MP3.
    Falls back to empty string on failure.
    """
    try:
        from gtts import gTTS
        tts = gTTS(text=text, lang=lang, slow=False)
        buf = io.BytesIO()
        tts.write_to_fp(buf)
        buf.seek(0)
        encoded = base64.b64encode(buf.read()).decode("utf-8")
        return encoded
    except Exception:
        logger.error(traceback.format_exc())
        return ""


#  Contextual follow-up 

def get_follow_up_or_next(
    previous_answer: str,
    current_question: str,
    remaining_questions: int,
) -> str | None:
    """
    Optionally generate a short follow-up probe if the answer is vague.
    Returns None if no follow-up is warranted.
    """
    if not previous_answer.strip():
        return None
    if remaining_questions <= 1:
        return None
    prompt = f"""
A candidate just gave this answer to a question. 

Question: {current_question}
Answer: {previous_answer}

Do NOT be polite. If the answer is vague, too short, avoids the technical depth required, or doesn't actually answer the prompt, write a sharp, investigative follow-up question (max 20 words).
If the answer is comprehensive and high-quality, respond with exactly: NO_FOLLOWUP
"""
    try:
        response = _safe_generate(prompt)
        result = response.text.strip()
        if result == "NO_FOLLOWUP" or "NO_FOLLOWUP" in result:
            return None
        return result[:200]
    except Exception:
        return None
