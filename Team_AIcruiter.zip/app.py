"""
AI Interview System — Flask Backend
=====================================
Routes
------
POST /api/upload          — Upload CV + JD, create candidate, generate questions
GET  /api/questions/<id>  — Return generated questions for a session
POST /api/analyse-frame   — Receive a webcam frame, run facial analysis
POST /api/submit-answer   — Save a candidate's spoken/typed answer + score it
POST /api/end-interview   — Finalise session, generate report, persist to Supabase
GET  /api/report/<id>     — Retrieve completed report
GET  /api/candidates      — List all candidates (admin)
POST /api/tts             — Convert text to speech (base64 MP3)
"""

import os
import uuid
import json
import logging
import traceback
from pathlib import Path
from functools import wraps
from flask import Flask, request, jsonify, send_from_directory, render_template, redirect, url_for, Response, session
from flask_cors import CORS
from flask_bcrypt import Bcrypt

from config import UPLOAD_FOLDER, MAX_CONTENT_MB, SECRET_KEY, SUPABASE_URL, SUPABASE_BUCKET

#  App setup 
app = Flask(__name__, static_folder="static", static_url_path="")
app.secret_key = SECRET_KEY
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_MB * 1024 * 1024
app.config["TEMPLATES_AUTO_RELOAD"] = True
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0
app.jinja_env.auto_reload = True
CORS(app, origins="*")
bcrypt = Bcrypt(app)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

Path(UPLOAD_FOLDER).mkdir(exist_ok=True)

# In-memory session store (persisted to Firebase at end)
# { session_id: { candidate_id, cv_text, jd_text, questions, qa_pairs, ... } }
_sessions: dict[str, dict] = {}

ALLOWED_EXT = {".pdf", ".docx", ".doc", ".txt"}


def _allowed(filename: str) -> bool:
    return Path(filename).suffix.lower() in ALLOWED_EXT


# Auth Decorator 

def requires_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated


def _session(sid: str) -> dict | None:
    return _sessions.get(sid)


@app.after_request
def add_no_cache_headers(response):
    # Avoid stale admin/candidate pages while iterating on UI.
    if response.mimetype == "text/html":
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response


def _normalise_question_type(raw_type: str | None) -> str:
    text = str(raw_type or "").strip()
    if not text:
        return "GENERAL"
    return text.replace("-", "_").replace(" ", "_").upper()


def _build_category_performance(questions: list | None, qa_pairs: list | None) -> dict:
    questions = questions or []
    qa_pairs = qa_pairs or []

    grouped: dict[str, dict] = {}
    order: list[str] = []

    for idx, qa in enumerate(qa_pairs):
        q_index = idx
        if isinstance(qa, dict):
            try:
                q_index = int(qa.get("question_index", idx))
            except (TypeError, ValueError):
                q_index = idx

        if q_index < 0:
            q_index = idx

        q_meta = questions[q_index] if q_index < len(questions) and isinstance(questions[q_index], dict) else {}

        raw_type = None
        if isinstance(qa, dict):
            raw_type = qa.get("question_type") or qa.get("category")
        if not raw_type and isinstance(q_meta, dict):
            raw_type = q_meta.get("question_type") or q_meta.get("category")

        q_type = _normalise_question_type(raw_type)

        if q_type not in grouped:
            grouped[q_type] = {"scores": [], "feedbacks": [], "question_count": 0}
            order.append(q_type)

        grouped[q_type]["question_count"] += 1

        score_obj = qa.get("score") if isinstance(qa, dict) else None
        if isinstance(score_obj, dict):
            raw_score = score_obj.get("overall_score")
            try:
                numeric = float(raw_score)
                numeric = max(0.0, min(10.0, numeric))
                grouped[q_type]["scores"].append(numeric)
            except (TypeError, ValueError):
                pass

            feedback_text = str(score_obj.get("feedback") or "").strip()
            if feedback_text:
                grouped[q_type]["feedbacks"].append(feedback_text)

    category_scores: list[dict] = []
    category_feedback: list[dict] = []

    for q_type in order:
        item = grouped[q_type]
        scores = item["scores"]
        avg_score = round(sum(scores) / len(scores), 1) if scores else 0.0
        percent = round((avg_score / 10.0) * 100)
        label = q_type.replace("_", " ").title()

        if avg_score >= 8:
            summary = f"Strong {label.lower()} performance with consistently high-quality answers."
        elif avg_score >= 6:
            summary = f"Good {label.lower()} performance with room to deepen some responses."
        elif avg_score >= 4:
            summary = f"Moderate {label.lower()} performance; needs more clarity and depth."
        else:
            summary = f"{label} needs improvement to meet role expectations."

        if item["feedbacks"]:
            summary = f"{summary} {item['feedbacks'][0]}"

        category_scores.append({
            "type_key": q_type,
            "type_label": label,
            "score_out_of_10": avg_score,
            "score_percent": percent,
            "question_count": item["question_count"],
        })

        category_feedback.append({
            "type_key": q_type,
            "type_label": label,
            "score_out_of_10": avg_score,
            "summary": summary,
        })

    return {
        "category_scores": category_scores,
        "category_feedback": category_feedback,
    }


def _attach_category_performance(candidate: dict | None) -> dict | None:
    if not candidate:
        return candidate

    sessions = candidate.get("interview_sessions") or []
    first_session = sessions[0] if sessions else {}
    questions = first_session.get("questions", []) if isinstance(first_session, dict) else []
    qa_pairs = first_session.get("qa_pairs", []) if isinstance(first_session, dict) else []

    metrics = _build_category_performance(questions, qa_pairs)
    candidate["category_scores"] = metrics["category_scores"]
    candidate["category_feedback"] = metrics["category_feedback"]

    final_reports = candidate.get("final_reports") or []
    if final_reports and isinstance(final_reports[0], dict):
        final_reports[0]["category_scores"] = metrics["category_scores"]
        final_reports[0]["category_feedback"] = metrics["category_feedback"]

    return candidate


#  Serve frontend 

@app.route("/")
def index():
    meeting_id = (request.args.get("meetingId") or "").strip()
    if meeting_id:
        if meeting_id.lower().endswith("/interview_complete"):
            return render_template("candidate/interview_complete.html")
        if meeting_id.lower().endswith("/interview"):
            return render_template("candidate/interview_conduct.html")
        return render_template("candidate/candidate_registration.html")
    return send_from_directory("static", "index.html")


#  Admin Routes 

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        from supabase_service import get_user_by_email
        email    = (request.form.get("email") or "").strip()
        password = request.form.get("password") or ""

        user = get_user_by_email(email)
        if user and bcrypt.check_password_hash(user['password'], password):
            session['user_id']   = user['id']
            session['user_name'] = user.get('name', 'Admin')
            return redirect(url_for('admin_dashboard'))

        return render_template("admin/login.html", error="Invalid email or password")

    return render_template("admin/login.html")


@app.route("/admin/register", methods=["POST"])
def admin_register():
    from supabase_service import get_user_by_email, create_user
    email    = (request.form.get("email") or "").strip()
    password = request.form.get("password") or ""
    name     = (request.form.get("name") or "").strip()

    if get_user_by_email(email):
        return render_template("admin/login.html", reg_error="An account with this email already exists.")

    password_hash = bcrypt.generate_password_hash(password).decode('utf-8')
    user_id = create_user(email, password_hash, name)

    if user_id:
        session['user_id']   = user_id
        session['user_name'] = name or email.split("@")[0]
        return redirect(url_for('admin_dashboard'))

    return render_template("admin/login.html", reg_error="Registration failed. Please try again.")


@app.route("/admin/logout")
def admin_logout():
    session.clear()
    return redirect(url_for('admin_login'))

@app.route("/admin")
@requires_auth
def admin_dashboard():
    from supabase_service import _get_client
    user_id = session.get('user_id')
    
    # Fetch EVERYTHING from meetings table for this user
    client = _get_client()
    query = client.table("meetings").select("*").order("created_at", desc=True)
    if user_id:
        query = query.eq("user_id", user_id)
    all_data = query.execute().data or []
    
    base_url = request.host_url.rstrip('/')
    
    return render_template("admin/index.html", 
                         meetings=all_data, 
                         base_url=base_url,
                         user_name=session.get('user_name', 'Admin'))


@app.route("/admin/meeting_links")
@requires_auth
def admin_meeting_links():
    from supabase_service import get_all_meetings, get_candidates_for_meetings
    user_id = session.get('user_id')
    meetings = get_all_meetings(user_id=user_id)
    meetings.sort(key=lambda x: x.get('created_at', ''), reverse=True)

    # Compute candidate counts and a lightweight conducted status per meeting
    meeting_ids = [m.get('meeting_id') for m in meetings if m.get('meeting_id')]
    candidates = get_candidates_for_meetings(meeting_ids)
    # Build a map: meeting_id -> { total, completed }
    counts = {}
    for c in candidates:
        mid = c.get('meeting_id')
        if not mid: continue
        rec = counts.setdefault(mid, {'total': 0, 'completed': 0})
        rec['total'] += 1
        if (c.get('status') or '').lower() == 'completed':
            rec['completed'] += 1

    for m in meetings:
        mid = m.get('meeting_id')
        rec = counts.get(mid, {'total': 0, 'completed': 0})
        m['candidate_count'] = rec['total']
        m['completed_count'] = rec['completed']
        # If any candidate has completed the interview, mark the meeting as conducted
        m['conducted_status'] = 'completed' if rec['completed'] > 0 else 'pending'

    return render_template(
        "admin/all_interview_links.html",
        meetings=meetings,
        user_name=session.get('user_name', 'Admin')
    )


@app.route("/admin/create-job")
@requires_auth
def admin_create_job_page():
    return render_template("admin/create_job.html", user_name=session.get('user_name', 'Admin'))

@app.route("/admin/api/create-job", methods=["POST"])
@requires_auth
def admin_api_create_job():
    from supabase_service import create_meeting, upload_document
    from deepseek_service import extract_text_from_file
    
    title = request.form.get("job_title")
    level = request.form.get("job_level", "Unknown")
    jd_file = request.files.get("jd_file")
    
    if not jd_file or not jd_file.filename:
        return jsonify({"success": False, "error": "Job Description (JD) PDF is required"}), 400
        
    try:
        temp_id = str(uuid.uuid4())
        session_dir = Path(UPLOAD_FOLDER) / temp_id
        session_dir.mkdir(parents=True, exist_ok=True)
        
        jd_ext = Path(jd_file.filename).suffix.lower()
        jd_path = session_dir / f"jd{jd_ext}"
        jd_file.save(jd_path)
        jd_text = extract_text_from_file(str(jd_path))

        if not jd_text.strip() or len(jd_text.strip()) < 20:
            return jsonify({"success": False, "error": "Insufficient text from Job Description"}), 400

        job_id = create_meeting(
            job_title=title, 
            jd_text=jd_text, 
            cv_text="##JOB_TEMPLATE##", 
            interview_types=[f"LEVEL:{level}"], 
            question_count=-1, 
            user_id=session.get('user_id')
        )
        
        if job_id:
            upload_document(str(jd_path), f"meetings/{job_id}/jd{jd_ext}")
            return jsonify({"success": True, "job_id": job_id})
        return jsonify({"success": False, "error": "Database error"}), 500
    except Exception as e:
        logger.error(traceback.format_exc())
        return jsonify({"success": False, "error": str(e)}), 500

@app.route("/admin/created_interviews_<job_id>")
@requires_auth
def admin_job_details(job_id):
    from supabase_service import get_meeting, get_all_meetings
    job = get_meeting(job_id)
    if not job or job.get("question_count") != -1:
        return "Job not found", 404
        
    all_meetings = get_all_meetings(session.get("user_id"))
    job_interviews = [m for m in all_meetings if m.get("interview_types") and isinstance(m["interview_types"], list) and f"JOBID:{job_id}" in m["interview_types"]]

    # Fetch candidate statuses to show Conducted/Not Conducted
    from supabase_service import get_candidates_for_meetings
    m_ids = [m["meeting_id"] for m in job_interviews]
    candidates = get_candidates_for_meetings(m_ids)
    status_map = {c["meeting_id"]: c["status"] for c in candidates}
    
    for m in job_interviews:
        m["conducted_status"] = status_map.get(m["meeting_id"], "pending")
    
    return render_template(
        "admin/all_interview_links.html",
        meetings=job_interviews,
        user_name=session.get('user_name', 'Admin'),
        job=job
    )

@app.route("/admin/create-interview/<job_id>")
@requires_auth
def admin_create_interview_page(job_id):
    from supabase_service import get_meeting
    job = get_meeting(job_id)
    if not job:
        return "Job not found", 404
    return render_template("admin/create_interview.html", user_name=session.get('user_name', 'Admin'), job=job)

@app.route("/admin/api/create-interview/<job_id>", methods=["POST"])
@requires_auth
def admin_api_create_interview(job_id):
    from supabase_service import get_meeting, create_meeting, upload_document
    from deepseek_service import extract_text_from_file
    
    job = get_meeting(job_id)
    if not job:
        return jsonify({"success": False, "error": "Job not found"}), 404
        
    candidate_name = (request.form.get("candidate_name") or "").strip()
    candidate_email = (request.form.get("candidate_email") or "").strip()
    interview_types = request.form.getlist("interview_types")
    question_count = request.form.get("question_count", type=int, default=10)
    cv_file = request.files.get("cv_file")
    
    if not cv_file or not cv_file.filename:
        return jsonify({"success": False, "error": "Candidate CV is required"}), 400
        
    try:
        temp_id = str(uuid.uuid4())
        session_dir = Path(UPLOAD_FOLDER) / temp_id
        session_dir.mkdir(parents=True, exist_ok=True)
        
        cv_ext = Path(cv_file.filename).suffix.lower()
        cv_path = session_dir / f"cv{cv_ext}"
        cv_file.save(cv_path)
        cv_text = extract_text_from_file(str(cv_path))
        
        if not cv_text.strip() or len(cv_text.strip()) < 50:
             return jsonify({"success": False, "error": "Insufficient text from CV"}), 400

        # Inject Job ID and Candidate metadata into interview_types
        extended_types = list(interview_types)
        extended_types.append(f"JOBID:{job_id}")
        if candidate_email:
            extended_types.append(f"EMAIL:{candidate_email}")
        if candidate_name:
            extended_types.append(f"NAME:{candidate_name}")
        
        meeting_id = create_meeting(
            job_title=job.get("job_title"), 
            jd_text=job.get("jd_text"), 
            cv_text=cv_text, 
            interview_types=extended_types, 
            question_count=question_count, 
            user_id=session.get('user_id')
        )
        
        if meeting_id:
            upload_document(str(cv_path), f"meetings/{meeting_id}/cv{cv_ext}")
            
            # Generate the questions right now!
            from deepseek_service import generate_interview_questions
            import json
            
            # Extract job level (stored as "LEVEL:Intern" or "LEVEL:Associate")
            job_level = "Associate"
            if job.get("interview_types"):
                lv = next((t for t in job.get("interview_types") if t.startswith("LEVEL:")), None)
                if lv: job_level = lv.replace("LEVEL:", "")
                
            logger.info("Generating questions for new meeting %s (Level: %s)", meeting_id, job_level)
            questions = generate_interview_questions(
                cv_text, 
                job.get("jd_text"), 
                extended_types, 
                question_count=question_count,
                job_level=job_level
            )
            
            if not questions:
                logger.error("Failed to generate questions for meeting %s", meeting_id)
                return jsonify({"success": False, "error": "AI could not generate questions. Please try again with a clearer CV/JD."}), 500

            # Save questions into Supabase Storage
            questions_path = session_dir / "questions.json"
            try:
                with open(questions_path, "w", encoding="utf-8") as f:
                    json.dump(questions, f, indent=2)
                
                upload_res = upload_document(str(questions_path), f"meetings/{meeting_id}/questions.json")
                if not upload_res:
                    logger.error("Failed to upload questions.json to storage for meeting %s", meeting_id)
                    # We continue because maybe the candidate join flow can recover, 
                    # but for admin review it's bad.
            except Exception as e:
                logger.error("Post-generation file ops failed: %s", str(e))

            from urllib.parse import urlencode
            params = {
                "candidate_email": candidate_email,
                "candidate_name": candidate_name,
                "job_title": job.get("job_title")
            }
            next_url = f"/admin/interview-questions/{meeting_id}?{urlencode(params)}"
            
            return jsonify({
                "success": True,
                "meeting_id": meeting_id,
                "next_url": next_url,
                "interview_link": f"{request.host_url.rstrip('/')}/?meetingId={meeting_id}"
            })
        return jsonify({"success": False, "error": "Database error"}), 500
    except Exception as e:
        logger.error("admin_api_create_interview failed: %s", str(e))
        logger.error(traceback.format_exc())
        return jsonify({"success": False, "error": str(e)}), 500
        
@app.route("/admin/interview-questions/<meeting_id>")
@requires_auth
def admin_interview_questions(meeting_id):
    from config import SUPABASE_URL, SUPABASE_BUCKET
    from supabase_service import download_document
    import requests
    import json
    import time
    
    questions = []
    
    # Try downloading directly using the Supabase client first (bypasses CDN cache completely)
    questions_data = download_document(f"meetings/{meeting_id}/questions.json")
    if questions_data:
        try:
            questions = json.loads(questions_data.decode("utf-8"))
            logger.info("Using pre-approved questions (downloaded) for review: %s", meeting_id)
        except Exception as e:
            logger.warning("Failed to parse downloaded questions JSON: %s", str(e))
            
    if not questions:
        from supabase_service import get_meeting, upload_document
        from deepseek_service import generate_interview_questions
        
        logger.info("ℹ️ questions.json not found for meeting %s. Attempting on-the-fly recovery generation...", meeting_id)
        mtg = get_meeting(meeting_id)
        
        if mtg and mtg.get("cv_text") and mtg.get("jd_text"):
            cv_text = mtg.get("cv_text")
            jd_text = mtg.get("jd_text")
            q_count = mtg.get("question_count") or 10
            if q_count == -1: q_count = 10 # Jobs use -1, but interviews use actual count
            
            # Extract job level if possible
            job_level = "Associate"
            types = mtg.get("interview_types") or []
            lv = next((t for t in types if isinstance(t, str) and t.startswith("LEVEL:")), None)
            if lv: job_level = lv.replace("LEVEL:", "")
            
            try:
                questions = generate_interview_questions(
                    cv_text, jd_text, types, question_count=q_count, job_level=job_level
                )
                if questions:
                    # Save them so we don't have to re-generate next time
                    temp_id = str(uuid.uuid4())
                    session_dir = Path(UPLOAD_FOLDER) / temp_id
                    session_dir.mkdir(parents=True, exist_ok=True)
                    q_path = session_dir / "questions.json"
                    with open(q_path, "w", encoding="utf-8") as f:
                        json.dump(questions, f, indent=2)
                    upload_document(str(q_path), f"meetings/{meeting_id}/questions.json")
                    logger.info("✅ Recovery generation successful for meeting %s", meeting_id)
            except Exception as e:
                logger.error("❌ Recovery generation failed for meeting %s: %s", meeting_id, str(e))
        
    # Clean question types for display (handle legacy data or tags)
    for q in questions:
        q_type = str(q.get("question_type", "")).upper()
        if any(q_type.startswith(pref) for pref in ["EMAIL:", "NAME:", "JOBID:", "LEVEL:"]) or not q_type:
            q["question_type"] = "PROBLEM SOLVING" # Use a safe default
        q["question_type"] = q["question_type"].replace("_", " ")
        
    return render_template(
        "admin/interview_questions.html",
        meeting_id=meeting_id,
        questions=questions,
        job_title=(request.args.get("job_title") or "").strip(),
        candidate_email=(request.args.get("candidate_email") or "").strip(),
        candidate_name=(request.args.get("candidate_name") or "").strip()
    )

@app.route("/admin/api/approve-questions/<meeting_id>", methods=["POST"])
@requires_auth
def admin_api_approve_questions(meeting_id):
    from supabase_service import upload_document
    import json
    
    data = request.json
    questions = data.get("questions", [])
    
    try:
        temp_id = str(uuid.uuid4())
        session_dir = Path(UPLOAD_FOLDER) / temp_id
        session_dir.mkdir(parents=True, exist_ok=True)
        
        questions_path = session_dir / "questions.json"
        with open(questions_path, "w", encoding="utf-8") as f:
            json.dump(questions, f, indent=2)
            
        upload_res = upload_document(str(questions_path), f"meetings/{meeting_id}/questions.json")
        if not upload_res:
             return jsonify({"success": False, "error": "Failed to save questions to Supabase Storage. Check your Storage RLS policies (UPDATE/DELETE) or use the service_role key."}), 500
        
        # ⚠️ CRITICAL: Update any active in-memory sessions for this meeting
        updated_count = 0
        for sid, sess_data in list(_sessions.items()):
            if sess_data.get("candidate", {}).get("meeting_id") == meeting_id or sess_data.get("meeting_id") == meeting_id:
                sess_data["questions"] = questions
                updated_count += 1
        
        if updated_count > 0:
            logger.info("Updated %d active sessions with new approved questions for meeting %s", updated_count, meeting_id)

        return jsonify({"success": True})
    except Exception as e:
        logger.error(traceback.format_exc())
        return jsonify({"success": False, "error": str(e)}), 500

@app.route("/admin/send-email/<meeting_id>")
@requires_auth
def admin_send_email(meeting_id):
    meeting_id = (meeting_id or "").strip().upper()
    if not meeting_id:
        return redirect(url_for("admin_meeting_links"))

    interview_link = f"{request.host_url.rstrip('/')}/?meetingId={meeting_id}"
    return render_template(
        "admin/interview_link_created.html",
        meeting_id=meeting_id,
        interview_link=interview_link,
        job_title=(request.args.get("job_title") or "").strip(),
        candidate_email=(request.args.get("candidate_email") or "").strip(),
        user_name=session.get('user_name', 'Admin')
    )


@app.route("/admin/candidates_performance")
@requires_auth
def admin_candidates_performance():
    from supabase_service import get_all_candidates, get_candidate, get_meeting
    user_id = session.get('user_id')
    candidates = get_all_candidates(user_id=user_id)
    for c in candidates:
        candidate_id = c.get("id")
        meeting_job_title = ""
        meeting_id = c.get("meeting_id")
        if meeting_id:
            meeting = get_meeting(meeting_id)
            if meeting:
                meeting_job_title = (meeting.get("job_title") or "").strip()

        if meeting_job_title:
            c["position_title"] = meeting_job_title
        else:
            c["position_title"] = (c.get("job_title") or "").strip() or "N/A"

        score = 0
        if candidate_id:
            detailed = get_candidate(candidate_id)
            if detailed:
                _attach_category_performance(detailed)
                c["category_scores"] = detailed.get("category_scores", [])
                
                reports = detailed.get("final_reports", [])
                if reports and isinstance(reports[0], dict):
                    score = reports[0].get("overall_score", 0)
            else:
                c["category_scores"] = []
        else:
            c["category_scores"] = []
        c["overall_score"] = score

    # Sort candidates by marks (Highest to Lowest)
    candidates.sort(key=lambda x: x.get("overall_score", 0), reverse=True)

    return render_template(
        "admin/Candidates_performance.html",
        candidates=candidates,
        user_name=session.get('user_name', 'Admin')
    )


@app.route("/admin/performance/job/<job_id>", strict_slashes=False)
@requires_auth
def admin_job_performance(job_id):
    from supabase_service import get_meeting, get_candidates_for_meetings, get_candidate, _get_client
    user_id = session.get('user_id')
    
    job = get_meeting(job_id)
    if not job:
        return "Job not found", 404
        
    client = _get_client()
    # 1. Start with the job itself
    m_ids = [job_id]
    
    # 2. Find all interviews linked to this job (those with JOBID:job_id in interview_types)
    all_meetings = client.table("meetings").select("*").order("created_at", desc=True).execute().data or []
    interview_meetings = [m for m in all_meetings if m.get("interview_types") and isinstance(m["interview_types"], list) and f"JOBID:{job_id}" in m["interview_types"]]
    
    for m in interview_meetings:
        mid = m.get("meeting_id")
        if mid and mid not in m_ids:
            m_ids.append(mid)
            
    # Get all candidates for these meetings
    candidates = get_candidates_for_meetings(m_ids)
    
    detailed_candidates = []
    for c in candidates:
        if c.get("status") == "completed":
            det = get_candidate(c["id"])
            if det:
                _attach_category_performance(det)
                reports = det.get("final_reports", [])
                score = 0
                if reports and isinstance(reports[0], dict):
                    score = reports[0].get("overall_score", 0)
                
                det["overall_score"] = score
                detailed_candidates.append(det)

    # Sort candidates by marks. 
    # User said "ascending" in the last prompt but "high to low" previously.
    # In a leaderboard context, high to low (descending) is the standard for "prioritizing high marks".
    detailed_candidates.sort(key=lambda x: x.get("overall_score", 0), reverse=True)
    
    return render_template(
        "admin/Job_performance.html",
        job=job,
        candidates=detailed_candidates,
        user_name=session.get('user_name', 'Admin')
    )


@app.route("/admin/candidate/<candidate_id>")
@requires_auth
def admin_candidate_detail(candidate_id):
    from supabase_service import get_candidate
    candidate = get_candidate(candidate_id)
    if not candidate:
        return "Candidate not found", 404

    _attach_category_performance(candidate)
    
    meeting_id = candidate.get("meeting_id")
    # Use our proxy route so we don't have to guess the extension
    cv_url = f"/admin/download-file/{meeting_id}/cv" if meeting_id else "#"
    jd_url = f"/admin/download-file/{meeting_id}/jd" if meeting_id else "#"

    return render_template("admin/candidate.html", 
                         candidate=candidate, 
                         cv_url=cv_url,
                         jd_url=jd_url)


@app.route("/admin/candidate/<candidate_id>/transcript")
@requires_auth
def admin_candidate_transcript(candidate_id):
    from supabase_service import get_candidate
    candidate = get_candidate(candidate_id)
    if not candidate:
        return "Candidate not found", 404

    return render_template("admin/transcript.html", candidate=candidate)


@app.route("/admin/create-meeting", methods=["POST"])
@requires_auth
def admin_create_meeting():
    from supabase_service import create_meeting, upload_document
    from deepseek_service import extract_text_from_file
    
    title = request.form.get("job_title")
    candidate_email = (request.form.get("candidate_email") or "").strip()
    interview_types = request.form.getlist("interview_types")
        
    question_count = request.form.get("question_count", type=int, default=10)
    
    cv_file = request.files.get("cv_file")
    jd_file = request.files.get("jd_file")
    
    if not cv_file or not cv_file.filename:
        return jsonify({"success": False, "error": "Candidate CV is required"}), 400

    if not jd_file or not jd_file.filename:
        return jsonify({"success": False, "error": "Job Description (JD) PDF is required"}), 400
        
    try:
        temp_id = str(uuid.uuid4())
        session_dir = Path(UPLOAD_FOLDER) / temp_id
        session_dir.mkdir(parents=True, exist_ok=True)
        
        cv_ext = Path(cv_file.filename).suffix.lower()
        cv_path = session_dir / f"cv{cv_ext}"
        cv_file.save(cv_path)
        cv_text = extract_text_from_file(str(cv_path))
        
        if not cv_text.strip() or len(cv_text.strip()) < 50:
             return jsonify({"success": False, "error": "Could not extract sufficient text from Candidate CV. Please ensure it is a text-based PDF (not an image)."}), 400

        #  Handle JD (required)
        jd_ext = Path(jd_file.filename).suffix.lower()
        jd_path = session_dir / f"jd{jd_ext}"
        jd_file.save(jd_path)
        jd_text = extract_text_from_file(str(jd_path))

        if not jd_text.strip() or len(jd_text.strip()) < 20:
            return jsonify({"success": False, "error": "Could not extract sufficient text from Job Description PDF. Please ensure it is a text-based PDF (not an image)."}), 400

        #  Create Meeting
        meeting_id = create_meeting(title, jd_text, cv_text, interview_types, 
                                    question_count=question_count, 
                                    user_id=session.get('user_id'))
        
        if meeting_id:
            # Persistent Storage for Admin visibility
            upload_document(str(cv_path), f"meetings/{meeting_id}/cv{cv_ext}")
            upload_document(str(jd_path), f"meetings/{meeting_id}/jd{jd_ext}")

            interview_link = f"{request.host_url.rstrip('/')}/?meetingId={meeting_id}"
                
            return jsonify({
                "success": True,
                "meeting_id": meeting_id,
                "interview_link": interview_link,
                "job_title": title or "",
                "candidate_email": candidate_email,
            })
        
        return jsonify({"success": False, "error": "Database error"}), 500
        
    except Exception as e:
        logger.error(traceback.format_exc())
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/admin/delete-candidate/<candidate_id>", methods=["DELETE"])
@requires_auth
def api_delete_candidate(candidate_id):
    from supabase_service import delete_candidate
    if delete_candidate(candidate_id):
        return jsonify({"success": True})
    return jsonify({"success": False, "error": "Delete failed"}), 500


@app.route("/api/admin/delete-meeting/<meeting_id>", methods=["DELETE"])
@requires_auth
def api_delete_meeting(meeting_id):
    from supabase_service import delete_meeting
    if delete_meeting(meeting_id):
        return jsonify({"success": True})
    return jsonify({"success": False, "error": "Delete failed"}), 500


@app.route("/admin/download-file/<meeting_id>/<file_type>")
@requires_auth
def admin_download_file(meeting_id, file_type):
    """Generate a redirect URL for a specific meeting file (cv or jd)."""
    from supabase_service import _get_client
    from config import SUPABASE_BUCKET
    client = _get_client()
    if not client:
        return "Supabase not configured", 500
    
    try:
        # List files in the folder to find the correct extension
        res = client.storage.from_(SUPABASE_BUCKET).list(f"meetings/{meeting_id}")
        if not res:
            return "No files found for this meeting", 404
        
        # Find file starting with file_type (cv or jd)
        target_file = None
        for f in res:
            if f['name'].startswith(file_type):
                target_file = f['name']
                break
        
        if not target_file:
            return f"{file_type.upper()} not found", 404
            
        full_path = f"meetings/{meeting_id}/{target_file}"
        url = client.storage.from_(SUPABASE_BUCKET).get_public_url(full_path)
        return redirect(url)
    except Exception as e:
        logger.error(f"Download error: {e}")
        return str(e), 500


@app.route("/admin/calendar")
@requires_auth
def admin_calendar():
    from supabase_service import _get_client
    user_id = session.get('user_id')
    client = _get_client()
    query = client.table("meetings").select("*").neq("question_count", -1).order("created_at", desc=True)
    if user_id:
        query = query.eq("user_id", user_id)
    meetings = query.execute().data or []

    # Enrich with conducted_status
    from supabase_service import get_candidates_for_meetings
    m_ids = [m.get('meeting_id') for m in meetings if m.get('meeting_id')]
    candidates = get_candidates_for_meetings(m_ids)
    status_map = {c["meeting_id"]: c["status"] for c in candidates}
    for m in meetings:
        m["conducted_status"] = status_map.get(m.get("meeting_id"), "pending")

    return render_template("admin/calendar.html",
                           meetings=meetings,
                           user_name=session.get('user_name', 'Admin'))


@app.route("/api/admin/dashboard-stats")
@requires_auth
def api_dashboard_stats():
    from supabase_service import get_all_candidates, get_all_meetings
    user_id = session.get('user_id')
    candidates = get_all_candidates(user_id=user_id)
    meetings = get_all_meetings(user_id=user_id)
    
    completed = [c for c in candidates if c.get("status") == "completed"]
    recommended = [c for c in candidates if c.get("decision") == "Recommended"]
    
    return jsonify({
        "total_candidates": len(candidates),
        "total_meetings": len(meetings),
        "total_completed": len(completed),
        "total_hired": len(recommended)
    })





#  /api/upload 

# Global store for live frame viewing (admin)
_live_frames = {}

@app.route("/api/meeting/<meeting_id>", methods=["GET"])
def get_meeting_details(meeting_id: str):
    from supabase_service import get_meeting
    meeting = get_meeting(meeting_id)
    if not meeting:
        return jsonify({"error": "Meeting link invalid or expired."}), 404
    return jsonify(meeting)

@app.route("/api/auth/join-by-email", methods=["POST"])
def join_by_email():
    data = request.get_json(force=True)
    email = data.get("email")
    if not email:
        return jsonify({"error": "Email is required"}), 400
    
    from supabase_service import get_candidate_by_email, get_meeting
    candidate = get_candidate_by_email(email)
    if not candidate:
        return jsonify({"error": "No interview found for this email. Please check with your recruiter."}), 404
    
    meeting_id = candidate.get("meeting_id")
    if not meeting_id:
        return jsonify({"error": "Candidate is not linked to any meeting."}), 404
        
    meeting = get_meeting(meeting_id)
    if not meeting:
        return jsonify({"error": "Linked meeting no longer exists."}), 404
        
    return jsonify({
        "success": True,
        "candidate": candidate,
        "meeting": meeting
    })


@app.route("/api/upload", methods=["POST"])
def upload():
    """
    Expects multipart/form-data with:
      - name, email, phone (form fields)
      - meeting_id (REQUIRED)
    """
    try:
        from deepseek_service import generate_interview_questions
        from supabase_service import create_candidate, get_meeting

        meeting_id = request.form.get("meeting_id")
        if not meeting_id:
            return jsonify({"error": "Meeting ID is required to start the interview."}), 400
            
        mtg = get_meeting(meeting_id)
        if not mtg:
            return jsonify({"error": "Invalid or unavailable Meeting ID. Please check your link."}), 404
            
        jd_text = mtg.get("jd_text", "")
        cv_text = mtg.get("cv_text", "")
        job_title = mtg.get("job_title", "")
        interview_types = mtg.get("interview_types", [])

        if not cv_text or not jd_text:
             return jsonify({"error": "This meeting is not fully configured (missing CV or JD)."}), 400

        #  candidate info
        session_id = str(uuid.uuid4())
        candidate_data = {
            "name":       request.form.get("name", ""),
            "email":      request.form.get("email", ""),
            "phone":      request.form.get("phone", ""),
            "job_title":  job_title,
            "session_id": session_id,
            "meeting_id": meeting_id,
            "user_id":    mtg.get("user_id") # Owner of the meeting
        }

        if not candidate_data["name"] or not candidate_data["email"]:
            return jsonify({"error": "Name and Email are required to proceed."}), 400

        #  check for pre-approved questions or generate new ones
        from config import SUPABASE_URL, SUPABASE_BUCKET
        from supabase_service import download_document
        import requests
        import json
        import time
        
        questions = []
        
        # Try downloading directly using the Supabase client first (bypasses CDN cache completely)
        try:
            questions_data = download_document(f"meetings/{meeting_id}/questions.json")
            if questions_data:
                try:
                    questions = json.loads(questions_data.decode("utf-8"))
                    if isinstance(questions, list) and len(questions) > 0:
                        logger.info("✅ SUCCESS: Loaded %d pre-approved questions for meeting %s", len(questions), meeting_id)
                    else:
                        logger.warning("⚠️ WARNING: Downloaded questions.json is empty or not a list for meeting %s", meeting_id)
                        questions = []
                except Exception as e:
                    logger.warning("❌ ERROR: Failed to parse downloaded questions JSON for meeting %s: %s", meeting_id, str(e))
            else:
                logger.info("ℹ️ INFO: No questions.json found in storage for meeting %s", meeting_id)
        except Exception as e:
            logger.error("❌ ERROR: Exception during download_document for meeting %s: %s", meeting_id, str(e))
                
        if not questions:
            # Fallback to HTTP with a cache buster query parameter
            questions_url = f"{SUPABASE_URL}/storage/v1/object/public/{SUPABASE_BUCKET}/meetings/{meeting_id}/questions.json?t={int(time.time())}"
            logger.info("🔄 Trying HTTP fallback for questions: %s", questions_url)
            try:
                resp = requests.get(questions_url, headers={"Cache-Control": "no-cache", "Pragma": "no-cache"}, timeout=5)
                if resp.ok:
                    questions = resp.json()
                    if isinstance(questions, list) and len(questions) > 0:
                        logger.info("✅ SUCCESS: Loaded %d questions via HTTP fallback for meeting %s", len(questions), meeting_id)
                    else:
                        questions = []
            except Exception as e:
                logger.warning("❌ ERROR: HTTP fallback failed for meeting %s: %s", meeting_id, str(e))

        if not questions:
            logger.info("🚀 No pre-approved questions found. Generating fresh ones with DeepSeek for meeting %s…", meeting_id)
            q_count = mtg.get("question_count") or MAX_QUESTIONS
            interview_types = mtg.get("interview_types", [])
            try:
                questions = generate_interview_questions(cv_text, jd_text, interview_types, question_count=q_count)
                logger.info("✅ SUCCESS: Generated %d new questions with DeepSeek", len(questions))
            except Exception as e:
                logger.error("❌ Recovery generation failed for meeting %s: %s", meeting_id, str(e))

        #  store in Supabase
        from supabase_service import get_candidate_by_email, update_candidate
        existing = get_candidate_by_email(candidate_data["email"])
        
        if existing:
            candidate_id = existing["id"]
            update_candidate(candidate_id, {"session_id": session_id})
            logger.info("Using existing candidate: %s", candidate_id)
        else:
            candidate_id = create_candidate(candidate_data) or session_id

        #  store in memory
        _sessions[session_id] = {
            "session_id":   session_id,
            "candidate_id": candidate_id,
            "candidate":    candidate_data,
            "cv_text":      cv_text,
            "jd_text":      jd_text,
            "questions":    questions,
            "qa_pairs":     [],
            "current_q":    0,
            "facial_frames": [],
        }

        return jsonify({
            "success": True,
            "session_id": session_id,
            "candidate_id": candidate_id,
            "candidate": candidate_data,
            "questions": questions
        })


    except Exception as e:
        logger.error("Upload error: %s", traceback.format_exc())
        return jsonify({"error": str(e)}), 500



#  /api/questions/<session_id> 

@app.route("/api/questions/<session_id>", methods=["GET"])
def get_questions(session_id: str):
    sess = _session(session_id)
    if not sess:
        return jsonify({"error": "Session not found"}), 404
    return jsonify({
        "questions": sess["questions"],
        "current_q": sess["current_q"],
    })

@app.route("/api/interview/intro/<session_id>", methods=["GET"])
def get_interview_intro(session_id: str):
    sess = _session(session_id)
    if not sess:
        return jsonify({"error": "Session not found"}), 404
        
    candidate_name = sess["candidate"].get("name", "there")
    job_title = sess["candidate"].get("job_title", "Position")
    
    intro_text = (
        f"Hello {candidate_name}! Welcome to your {job_title} interview with AIcruiter. "
        f"I'm your AI interviewer today. Before we dive into our questions, "
        f"could you please tell me a little about yourself?"
    )
    
    from deepseek_service import text_to_speech_base64
    audio_b64 = text_to_speech_base64(intro_text)
    
    return jsonify({
        "text": intro_text,
        "audio": audio_b64,
        "ask_intro": True  # Signal to frontend to capture intro answer
    })


@app.route("/api/interview/save-intro/<session_id>", methods=["POST"])
def save_intro_answer(session_id: str):
    """Save the candidate's 'tell me about yourself' answer without scoring."""
    sess = _session(session_id)
    if not sess:
        return jsonify({"error": "Session not found"}), 404
    data = request.get_json(force=True)
    sess["intro_answer"] = data.get("intro_answer", "")
    logger.info("Intro answer saved for session %s", session_id)
    return jsonify({"success": True})


#  /api/next-question 

@app.route("/api/next-question/<session_id>", methods=["GET"])
def next_question(session_id: str):
    sess = _session(session_id)
    if not sess:
        return jsonify({"error": "Session not found"}), 404

    from deepseek_service import text_to_speech_base64

    # Use a separate state variable to track the "pending" question index
    # to avoid skipping if front-end calls this multiple times
    idx = sess.get("current_q", 0)
    questions = sess.get("questions", [])

    if idx >= len(questions):
        logger.info("Session %s: All questions completed.", session_id)
        return jsonify({"done": True})

    q = questions[idx]
    if isinstance(q, dict):
        if not q.get("question_type") and q.get("category"):
            q["question_type"] = str(q.get("category", "")).upper()
        if not q.get("category") and q.get("question_type"):
            q["category"] = str(q.get("question_type", "")).lower()
    else:
        q = {
            "id": idx + 1,
            "question": str(q),
            "question_type": "GENERAL",
            "category": "general",
        }
        questions[idx] = q

    logger.info("Session %s: Serving question %d: %s", session_id, idx, q["question"][:50])

    # Pre-generate TTS audio
    audio_b64 = text_to_speech_base64(q["question"])
    
    # Increment pointer only AFTER we are sure we are serving it
    sess["current_q"] = idx + 1

    return jsonify({
        "done":     False,
        "index":    idx,
        "question": q,
        "audio":    audio_b64,
        "total":    len(questions),
    })


@app.route("/api/interview/wrapup/<session_id>", methods=["GET"])
def get_interview_wrapup(session_id: str):
    sess = _session(session_id)
    if not sess:
        return jsonify({"error": "Session not found"}), 404
        
    candidate_name = sess["candidate"].get("name", "there")
    
    # Calculate a simple trend for summary
    scores = [qa.get("score", {}).get("overall_score", 5) for qa in sess.get("qa_pairs", [])]
    avg_score = sum(scores) / len(scores) if scores else 5
    
    if avg_score >= 8:
        summary = "That was great! You handled those tough questions like a pro. Your depth of knowledge is really impressive."
    elif avg_score >= 5:
        summary = "Well done! You have a solid foundation. Keep sharpening those skills and you'll be crushing projects in no time."
    else:
        summary = "Thanks for sharing your thoughts! Interviews can be tricky, but keep practicing and you'll get there. Every step counts!"

    wrapup_text = f"{summary} Thanks for chatting today! It was a pleasure meeting you. Hope to see you soon!"
    
    from deepseek_service import text_to_speech_base64
    audio_b64 = text_to_speech_base64(wrapup_text)
    
    return jsonify({
        "text": wrapup_text,
        "audio": audio_b64
    })


#  /api/submit-answer 

@app.route("/api/submit-answer", methods=["POST"])
def submit_answer():
    data = request.get_json(force=True)
    session_id = data.get("session_id")
    sess = _session(session_id)
    if not sess:
        return jsonify({"error": "Session not found"}), 404

    from deepseek_service import evaluate_answer, text_to_speech_base64

    q_index  = data.get("question_index", 0)
    answer   = data.get("answer", "").strip()
    questions = sess["questions"]

    if q_index >= len(questions):
        return jsonify({"error": "Invalid question index"}), 400

    question_payload = questions[q_index]
    if isinstance(question_payload, dict):
        question_text = str(question_payload.get("question", "")).strip()
        raw_type = question_payload.get("question_type") or question_payload.get("category") or "GENERAL"
        question_type = str(raw_type).strip().upper().replace(" ", "_")
        question_category = str(question_payload.get("category") or question_type.lower()).strip().lower()
    else:
        question_text = str(question_payload).strip()
        question_type = "GENERAL"
        question_category = "general"

    # Score the answer
    score = evaluate_answer(question_text, answer, sess["cv_text"], sess["jd_text"])

    pair = {
        "question_index": q_index,
        "question":       question_text,
        "question_type":  question_type,
        "category":       question_category,
        "answer":         answer,
        "score":          score,
    }
    sess["qa_pairs"].append(pair)

    #  Simplified Feedback (No investigative follow-up for now to save quota)
    # investigative_follow_up = get_follow_up_or_next(answer, question_text, remaining)
    follow_up = None 
    follow_up_audio = None

    # Acknowledgement TTS (shorter)
    ack_audio = None
    #  Witty Feedback based on score
    import random
    score_val = score.get("overall_score", 5)
    
    if score_val >= 8:
        ack_text = random.choice([
            "Nice! That’s a solid answer.",
            "Spot on! You really know your stuff.",
            "Impressive! You nailed that one.",
            "That was great! You're making this look easy.",
            "Boom! Perfect explanation."
        ])
    elif score_val >= 5:
        ack_text = random.choice([
            "Alright, good attempt!",
            "I see where you're going with that. Not bad!",
            "Fair enough! Let's keep the momentum going.",
            "Good point. You're on the right track."
        ])
    else:
        ack_text = random.choice([
            "Interesting! Not exactly what I was looking for, but I appreciate the effort.",
            "Hmm, not quite! But don't worry, we've got plenty more to cover.",
            "That's a tricky one, isn't it? Let's move on to the next challenge.",
            "No worries! Let's see how you tackle the next one."
        ])
    
    # Prefix with transition
    transitions = ["Alright, next up...", "Let’s tackle another one!", "Moving right along...", "Okay, let's see..."]
    
    ack_audio = text_to_speech_base64(ack_text)

    return jsonify({
        "score":           score,
        "ack_audio":       ack_audio,
        "ack_text":        ack_text,
        "follow_up":       follow_up,
        "follow_up_audio": follow_up_audio
    })


#  /api/analyse-frame 

@app.route("/api/analyse-frame", methods=["POST"])
def analyse_frame():
    data = request.get_json(force=True)
    session_id = data.get("session_id")
    frame_b64  = data.get("frame")     # data-URL or raw base64

    if not session_id or not frame_b64:
        return jsonify({"error": "Missing session_id or frame"}), 400

    # Store for live viewing with timestamp
    import time
    _live_frames[session_id] = {
        "frame": frame_b64,
        "last_seen": time.time()
    }

    from facial_analysis import analyse_frame as af
    result = af(frame_b64, session_id)
    return jsonify(result)

@app.route("/api/live-frame/<session_id>", methods=["GET"])
def get_live_frame(session_id: str):
    data = _live_frames.get(session_id)
    if not data:
        return jsonify({"error": "No frame available"}), 404
    # Check if it's a dict or old format string
    if isinstance(data, dict):
        return jsonify({"frame": data["frame"]})
    return jsonify({"frame": data})

@app.route("/api/active-sessions", methods=["GET"])
def get_active_sessions():
    """Returns a list of session_ids that have sent a frame in the last 60 seconds."""
    import time
    now = time.time()
    active = []
    for sid, data in _live_frames.items():
        if isinstance(data, dict):
            if now - data.get("last_seen", 0) < 60:
                active.append(sid)
    return jsonify({"active_sessions": active})


#  /api/end-interview 

@app.route("/api/end-interview", methods=["POST"])
def end_interview():
    data = request.get_json(force=True)
    session_id = data.get("session_id")
    sess = _session(session_id)
    if not sess:
        return jsonify({"error": "Session not found"}), 404

    from deepseek_service import generate_final_report, text_to_speech_base64
    from facial_analysis import get_emotion_summary, get_session_frames, clear_session
    from supabase_service import save_facial_data, save_interview_session, save_final_report

    candidate_id = sess["candidate_id"]
    facial_frames = get_session_frames(session_id)
    facial_summary = get_emotion_summary(session_id)

    #  Persist facial data
    save_facial_data(candidate_id, facial_frames)


    #  Generate final AI report
    logger.info("Generating final report for session %s…", session_id)

    # Prepend intro answer (tell me about yourself) to qa_pairs as a non-scored entry
    all_qa_pairs = list(sess.get("qa_pairs", []))
    intro_answer = sess.get("intro_answer", "")
    if intro_answer:
        intro_pair = {
            "question_index": -1,
            "question": "Can you tell me about yourself?",
            "question_type": "INTRODUCTION",
            "category": "introduction",
            "answer": intro_answer,
            "score": None,
            "is_intro": True,
        }
        all_qa_pairs = [intro_pair] + all_qa_pairs

    report = generate_final_report(
        candidate_info=sess["candidate"],
        jd_text=sess["jd_text"],
        qa_pairs=sess.get("qa_pairs", []),  # Score only real Q&A, not intro
        facial_summary=facial_summary,
    )

    category_metrics = _build_category_performance(sess.get("questions", []), sess.get("qa_pairs", []))
    report["category_scores"] = category_metrics["category_scores"]
    report["category_feedback"] = category_metrics["category_feedback"]

    report["facial_summary"] = facial_summary
    report["candidate"]      = sess["candidate"]

    #  Enforce score-based decision: >=50 = Recommended, <50 = Not Recommended
    overall_score = report.get("overall_score", 0)
    try:
        overall_score = float(overall_score)
    except (TypeError, ValueError):
        overall_score = 0.0
    report["decision"] = "Recommended" if overall_score >= 50 else "Not Recommended"

    #  Persist report (with intro in qa_pairs)
    save_interview_session(candidate_id, {
        "questions":  sess["questions"],
        "qa_pairs":   all_qa_pairs,  # Include intro answer at top
        "session_id": session_id,
    })
    # Remove the duplicate save below by returning early after this save
    save_final_report(candidate_id, report)

    #  TTS closing statement
    decision = report.get("decision", "Not Recommended")
    closing_map = {
        "Recommended":     "Congratulations! Based on your interview performance and our analysis, we are pleased to recommend you. You did great!",
        "Not Recommended": "Thank you for your time today. We appreciate your effort during the interview and will keep your details on file for future opportunities.",
    }
    closing_text = closing_map.get(decision, closing_map["Not Recommended"])
    closing_audio = text_to_speech_base64(closing_text)

    #  Clean up (skip duplicate save_interview_session — already done above)
    clear_session(session_id)
    _sessions.pop(session_id, None)

    return jsonify({
        "report":        report,
        "closing_text":  closing_text,
        "closing_audio": closing_audio,
        "candidate_id":  candidate_id,
    })


#  /api/report/<candidate_id> 

@app.route("/api/report/<candidate_id>", methods=["GET"])
def get_report(candidate_id: str):
    from supabase_service import get_candidate
    data = get_candidate(candidate_id)
    if not data:
        return jsonify({"error": "Candidate not found"}), 404
    _attach_category_performance(data)
    return jsonify(data)


#  /api/candidates 

@app.route("/api/candidates", methods=["GET"])
def list_candidates():
    from supabase_service import get_all_candidates
    candidates = get_all_candidates()
    return jsonify({"candidates": candidates, "count": len(candidates)})


#  /api/tts 

@app.route("/api/tts", methods=["POST"])
def tts():
    data = request.get_json(force=True)
    text = data.get("text", "")
    if not text:
        return jsonify({"error": "No text provided"}), 400
    from deepseek_service import text_to_speech_base64
    audio = text_to_speech_base64(text)
    return jsonify({"audio": audio})


#  /api/health 

@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "active_sessions": len(_sessions)})


@app.route("/<path:path>")
def static_files(path):
    return send_from_directory("static", path)


#  Entry point 

if __name__ == "__main__":
    import os
    port = int(os.environ.get("PORT", 7860))
    logger.info(f"Starting AI Interview System on http://0.0.0.0:{port}")
    app.run(debug=False, host="0.0.0.0", port=port, threaded=True)
